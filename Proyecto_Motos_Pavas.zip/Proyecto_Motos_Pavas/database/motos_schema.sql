-- ============================================================================
-- MÓDULO MOTOS — Taller de Motocicletas sobre plantilla PAVAS
-- Convención: prefijos de 3 letras por tabla, sta_id = estado (1 activo, 3 eliminado)
-- Ejecutar DESPUÉS de database/bdtemplate.sql (usa tbl_users y tbl_status si existen)
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Catálogos de estado reutilizables (si tbl_status ya existe en bdtemplate, omitir)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_moto_estados_orden (
  eso_id      INT PRIMARY KEY AUTO_INCREMENT,
  eso_nombre  VARCHAR(40)  NOT NULL,        -- Recibido, Diagnóstico, En reparación, Esperando repuestos, Terminado, Entregado, Cancelado
  eso_color   VARCHAR(20)  DEFAULT '#1976d2',
  eso_orden   INT          DEFAULT 0
);

INSERT INTO tbl_moto_estados_orden (eso_nombre, eso_color, eso_orden) VALUES
 ('Recibido', '#9e9e9e', 1),
 ('Diagnóstico', '#0288d1', 2),
 ('Esperando aprobación', '#fbc02d', 3),
 ('En reparación', '#f57c00', 4),
 ('Esperando repuestos', '#ab47bc', 5),
 ('Control de calidad', '#5c6bc0', 6),
 ('Terminado', '#43a047', 7),
 ('Entregado', '#2e7d32', 8),
 ('Cancelado', '#e53935', 9);

-- ---------------------------------------------------------------------------
-- Clientes del taller
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_moto_clientes (
  mcl_id              INT PRIMARY KEY AUTO_INCREMENT,
  mcl_nombre          VARCHAR(120) NOT NULL,
  mcl_identificacion  VARCHAR(30)  NOT NULL,
  mcl_telefono        VARCHAR(30),
  mcl_email           VARCHAR(120),
  mcl_direccion       VARCHAR(200),
  mcl_ciudad          VARCHAR(80)  DEFAULT 'Pasto',
  mcl_notas           TEXT,
  sta_id              TINYINT      DEFAULT 1,   -- 1 activo, 3 eliminado
  cre_fecha           DATETIME     DEFAULT CURRENT_TIMESTAMP,
  cre_usuario         INT,
  UNIQUE KEY uk_mcl_identificacion (mcl_identificacion)
);

-- ---------------------------------------------------------------------------
-- Mecánicos (referencian tbl_users existente; capacidad = # de órdenes simultáneas)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_moto_mecanicos (
  mmc_id           INT PRIMARY KEY AUTO_INCREMENT,
  use_id           INT NOT NULL,                -- FK lógica a tbl_users.use_id
  mmc_especialidad VARCHAR(120),
  mmc_capacidad    INT DEFAULT 5,               -- órdenes simultáneas máximas
  mmc_valor_hora   DECIMAL(12,2) DEFAULT 25000,
  sta_id           TINYINT DEFAULT 1,
  UNIQUE KEY uk_mmc_use (use_id)
);

-- ---------------------------------------------------------------------------
-- Motocicletas
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_motocicletas (
  mot_id            INT PRIMARY KEY AUTO_INCREMENT,
  mcl_id            INT NOT NULL,                -- FK -> tbl_moto_clientes
  mot_marca         VARCHAR(60) NOT NULL,
  mot_linea         VARCHAR(60),
  mot_modelo_anio   SMALLINT,
  mot_cilindraje    SMALLINT,
  mot_color         VARCHAR(40),
  mot_placa         VARCHAR(15) NOT NULL,
  mot_vin           VARCHAR(40),
  mot_motor_serial  VARCHAR(40),
  mot_kilometraje   INT DEFAULT 0,
  mot_proximo_mantenimiento_km INT DEFAULT NULL,  -- calculado: km_actual + 5000 (o según tipo)
  mot_fecha_proximo_mantenimiento DATE DEFAULT NULL,
  sta_id            TINYINT DEFAULT 1,
  cre_fecha         DATETIME DEFAULT CURRENT_TIMESTAMP,
  cre_usuario       INT,
  UNIQUE KEY uk_mot_placa (mot_placa),
  KEY idx_mot_cliente (mcl_id),
  CONSTRAINT fk_mot_cliente FOREIGN KEY (mcl_id) REFERENCES tbl_moto_clientes(mcl_id)
);

-- ---------------------------------------------------------------------------
-- Recepción (ingreso de la moto al taller)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_moto_recepcion (
  mrc_id                INT PRIMARY KEY AUTO_INCREMENT,
  mot_id                INT NOT NULL,
  mrc_fecha_ingreso     DATETIME DEFAULT CURRENT_TIMESTAMP,
  mrc_combustible_nivel TINYINT DEFAULT 50,      -- 0-100 %
  mrc_kilometraje       INT,
  mrc_estado_fisico     TEXT,                    -- descripción de rayones, golpes, etc.
  mrc_accesorios        TEXT,                    -- JSON o texto: casco, espejos, baúl...
  mrc_observaciones     TEXT,
  mrc_firma_cliente     LONGTEXT,                -- firma digital en base64 (dataURL)
  mrc_fotos             TEXT,                    -- JSON con rutas de fotos
  mrc_fecha_entrega_estimada DATE,
  cre_usuario           INT,
  KEY idx_mrc_moto (mot_id),
  CONSTRAINT fk_mrc_moto FOREIGN KEY (mot_id) REFERENCES tbl_motocicletas(mot_id)
);

-- ---------------------------------------------------------------------------
-- Órdenes de trabajo
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_ordenes_trabajo (
  ord_id                 INT PRIMARY KEY AUTO_INCREMENT,
  ord_numero             VARCHAR(20) NOT NULL,    -- OT-2026-00001
  mot_id                 INT NOT NULL,
  mrc_id                 INT,                     -- recepción asociada
  mmc_id                 INT,                      -- mecánico asignado
  eso_id                 INT DEFAULT 1,            -- estado (tbl_moto_estados_orden)
  ord_tipo_servicio      ENUM('preventivo','correctivo','diagnostico','garantia') DEFAULT 'correctivo',
  ord_prioridad          ENUM('baja','media','alta','urgente') DEFAULT 'media',
  ord_descripcion        TEXT,
  ord_diagnostico        TEXT,
  ord_horas_estimadas    DECIMAL(6,2) DEFAULT 0,
  ord_horas_invertidas   DECIMAL(6,2) DEFAULT 0,
  ord_fecha_inicio       DATETIME,
  ord_fecha_estimada_fin DATETIME,
  ord_fecha_fin_real     DATETIME,
  sta_id                 TINYINT DEFAULT 1,
  cre_fecha              DATETIME DEFAULT CURRENT_TIMESTAMP,
  cre_usuario            INT,
  UNIQUE KEY uk_ord_numero (ord_numero),
  KEY idx_ord_moto (mot_id),
  KEY idx_ord_mecanico (mmc_id),
  CONSTRAINT fk_ord_moto FOREIGN KEY (mot_id) REFERENCES tbl_motocicletas(mot_id),
  CONSTRAINT fk_ord_mecanico FOREIGN KEY (mmc_id) REFERENCES tbl_moto_mecanicos(mmc_id),
  CONSTRAINT fk_ord_estado FOREIGN KEY (eso_id) REFERENCES tbl_moto_estados_orden(eso_id)
);

-- Tareas/checklist dentro de una orden (para calcular % de avance con Math)
CREATE TABLE IF NOT EXISTS tbl_orden_tareas (
  ota_id         INT PRIMARY KEY AUTO_INCREMENT,
  ord_id         INT NOT NULL,
  ota_descripcion VARCHAR(200) NOT NULL,
  ota_completada TINYINT(1) DEFAULT 0,
  ota_horas      DECIMAL(6,2) DEFAULT 0,
  KEY idx_ota_orden (ord_id),
  CONSTRAINT fk_ota_orden FOREIGN KEY (ord_id) REFERENCES tbl_ordenes_trabajo(ord_id)
);

-- ---------------------------------------------------------------------------
-- Inventario de repuestos
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_inventario_repuestos (
  inv_id              INT PRIMARY KEY AUTO_INCREMENT,
  inv_codigo          VARCHAR(30) NOT NULL,
  inv_nombre          VARCHAR(150) NOT NULL,
  inv_categoria       VARCHAR(80),
  inv_stock_actual    INT DEFAULT 0,
  inv_stock_minimo    INT DEFAULT 5,             -- umbral de stock crítico
  inv_costo_unitario  DECIMAL(12,2) DEFAULT 0,
  inv_precio_venta    DECIMAL(12,2) DEFAULT 0,
  inv_proveedor       VARCHAR(120),
  sta_id              TINYINT DEFAULT 1,
  cre_fecha           DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_inv_codigo (inv_codigo)
);

-- Movimientos (entradas/salidas) — de aquí se calcula consumo diario promedio
CREATE TABLE IF NOT EXISTS tbl_inventario_movimientos (
  imv_id        INT PRIMARY KEY AUTO_INCREMENT,
  inv_id        INT NOT NULL,
  ord_id        INT DEFAULT NULL,                -- si la salida es por una orden de trabajo
  imv_tipo      ENUM('entrada','salida','ajuste') NOT NULL,
  imv_cantidad  INT NOT NULL,
  imv_fecha     DATETIME DEFAULT CURRENT_TIMESTAMP,
  imv_nota      VARCHAR(200),
  cre_usuario   INT,
  KEY idx_imv_repuesto (inv_id),
  CONSTRAINT fk_imv_repuesto FOREIGN KEY (inv_id) REFERENCES tbl_inventario_repuestos(inv_id)
);

-- Repuestos usados en una orden de trabajo (para facturación)
CREATE TABLE IF NOT EXISTS tbl_orden_repuestos (
  ore_id        INT PRIMARY KEY AUTO_INCREMENT,
  ord_id        INT NOT NULL,
  inv_id        INT NOT NULL,
  ore_cantidad  INT NOT NULL DEFAULT 1,
  ore_precio_unitario DECIMAL(12,2) NOT NULL,
  KEY idx_ore_orden (ord_id),
  CONSTRAINT fk_ore_orden FOREIGN KEY (ord_id) REFERENCES tbl_ordenes_trabajo(ord_id),
  CONSTRAINT fk_ore_repuesto FOREIGN KEY (inv_id) REFERENCES tbl_inventario_repuestos(inv_id)
);

-- ---------------------------------------------------------------------------
-- Facturación (cotizaciones y facturas)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_facturas (
  fac_id            INT PRIMARY KEY AUTO_INCREMENT,
  fac_numero        VARCHAR(20) NOT NULL,        -- COT-2026-0001 / FAC-2026-0001
  fac_tipo          ENUM('cotizacion','factura') DEFAULT 'cotizacion',
  ord_id            INT NOT NULL,
  mcl_id            INT NOT NULL,
  fac_mano_obra_horas   DECIMAL(6,2) DEFAULT 0,
  fac_valor_hora        DECIMAL(12,2) DEFAULT 0,
  fac_subtotal_mano_obra DECIMAL(12,2) DEFAULT 0,
  fac_subtotal_repuestos DECIMAL(12,2) DEFAULT 0,
  fac_subtotal          DECIMAL(12,2) DEFAULT 0,
  fac_descuento_porcentaje DECIMAL(5,2) DEFAULT 0,
  fac_descuento_valor      DECIMAL(12,2) DEFAULT 0,
  fac_iva_porcentaje    DECIMAL(5,2) DEFAULT 19,
  fac_iva_valor         DECIMAL(12,2) DEFAULT 0,
  fac_total             DECIMAL(12,2) DEFAULT 0,  -- redondeado con Math.round
  fac_estado            ENUM('pendiente','aprobada','pagada','anulada') DEFAULT 'pendiente',
  fac_fecha             DATETIME DEFAULT CURRENT_TIMESTAMP,
  cre_usuario           INT,
  UNIQUE KEY uk_fac_numero (fac_numero),
  KEY idx_fac_orden (ord_id),
  KEY idx_fac_cliente (mcl_id),
  CONSTRAINT fk_fac_orden FOREIGN KEY (ord_id) REFERENCES tbl_ordenes_trabajo(ord_id),
  CONSTRAINT fk_fac_cliente FOREIGN KEY (mcl_id) REFERENCES tbl_moto_clientes(mcl_id)
);

-- ---------------------------------------------------------------------------
-- Vista analítica para el dashboard (promedios / totales ya resueltos en SQL,
-- el detalle estadístico -max/min/percentiles- se calcula en JS con Math)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_moto_dashboard_ordenes AS
SELECT
  o.ord_id, o.ord_numero, o.eso_id, e.eso_nombre, o.ord_prioridad,
  o.ord_horas_estimadas, o.ord_horas_invertidas,
  o.ord_fecha_inicio, o.ord_fecha_estimada_fin, o.ord_fecha_fin_real,
  m.mot_placa, m.mot_marca, m.mot_linea,
  c.mcl_nombre
FROM tbl_ordenes_trabajo o
JOIN tbl_moto_estados_orden e ON e.eso_id = o.eso_id
JOIN tbl_motocicletas m ON m.mot_id = o.mot_id
JOIN tbl_moto_clientes c ON c.mcl_id = m.mcl_id
WHERE o.sta_id != 3;

-- ---------------------------------------------------------------------------
-- Datos iniciales de ejemplo (opcional, útil para probar el dashboard)
-- ---------------------------------------------------------------------------
INSERT INTO tbl_moto_clientes (mcl_nombre, mcl_identificacion, mcl_telefono, mcl_email, mcl_ciudad) VALUES
 ('Carlos Andrés Bravo', '1085123456', '3201234567', 'carlos.bravo@example.com', 'Pasto'),
 ('María Fernanda Rosero', '27458963', '3157894561', 'maria.rosero@example.com', 'Pasto');

INSERT INTO tbl_inventario_repuestos (inv_codigo, inv_nombre, inv_categoria, inv_stock_actual, inv_stock_minimo, inv_costo_unitario, inv_precio_venta, inv_proveedor) VALUES
 ('REP-001', 'Filtro de aceite', 'Filtros', 4, 10, 12000, 22000, 'Repuestos Nariño SAS'),
 ('REP-002', 'Kit de arrastre', 'Transmisión', 15, 5, 85000, 140000, 'Motopartes Andina'),
 ('REP-003', 'Pastillas de freno', 'Frenos', 20, 8, 25000, 45000, 'Repuestos Nariño SAS');
