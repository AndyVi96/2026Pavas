import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

const IVA_COLOMBIA = 0.19; // 19% — puede sobrescribirse por cotización

// ============================================================================
// === Math: motor de cálculo de cotizaciones/facturas ===
// Se expone también para que el frontend pueda previsualizar en tiempo real
// con la misma fórmula exacta (evita descuadres entre lo que ve el cliente
// y lo que se guarda en BD).
// ============================================================================
export const calcularFactura = ({
  horasManoObra = 0,
  valorHora = 0,
  repuestos = [],           // [{ cantidad, precioUnitario }]
  descuentoPorcentaje = 0,
  ivaPorcentaje = IVA_COLOMBIA * 100,
}) => {
  const horas = Number(horasManoObra) || 0;
  const valorH = Number(valorHora) || 0;

  // Costo de mano de obra según horas trabajadas
  const subtotalManoObra = horas * valorH;

  // Suma de repuestos (ganancia ya incluida en precioUnitario de venta)
  const subtotalRepuestos = repuestos.reduce(
    (acc, r) => acc + (Number(r.cantidad) || 0) * (Number(r.precioUnitario) || 0),
    0
  );

  const subtotal = subtotalManoObra + subtotalRepuestos;

  // Descuento
  const descuentoValor = subtotal * (Number(descuentoPorcentaje) / 100);
  const baseConDescuento = subtotal - descuentoValor;

  // IVA
  const ivaValor = baseConDescuento * (Number(ivaPorcentaje) / 100);

  // Total final redondeado al peso (Math.round evita centavos imposibles de cobrar)
  const total = Math.round(baseConDescuento + ivaValor);

  return {
    subtotalManoObra: Math.round(subtotalManoObra),
    subtotalRepuestos: Math.round(subtotalRepuestos),
    subtotal: Math.round(subtotal),
    descuentoValor: Math.round(descuentoValor),
    baseConDescuento: Math.round(baseConDescuento),
    ivaValor: Math.round(ivaValor),
    total,
  };
};

// === Math: ganancia estimada sobre repuestos (costo vs. precio de venta) ===
export const calcularGananciaRepuestos = (repuestos = []) => {
  const costoTotal = repuestos.reduce((acc, r) => acc + (Number(r.costoUnitario) || 0) * (Number(r.cantidad) || 0), 0);
  const ventaTotal = repuestos.reduce((acc, r) => acc + (Number(r.precioUnitario) || 0) * (Number(r.cantidad) || 0), 0);
  const ganancia = ventaTotal - costoTotal;
  const margenPorcentaje = ventaTotal > 0 ? Math.round((ganancia / ventaTotal) * 100) : 0;
  return { costoTotal: Math.round(costoTotal), ventaTotal: Math.round(ventaTotal), ganancia: Math.round(ganancia), margenPorcentaje };
};

const generarNumeroFactura = async (connection, tipo) => {
  const anio = new Date().getFullYear();
  const prefijo = tipo === "factura" ? "FAC" : "COT";
  const rows = await executeQuery(
    `SELECT COUNT(*) AS total FROM tbl_facturas WHERE fac_numero LIKE ?`,
    [`${prefijo}-${anio}-%`],
    connection
  );
  const siguiente = (rows[0]?.total ?? 0) + 1;
  return `${prefijo}-${anio}-${String(siguiente).padStart(4, "0")}`;
};

export const saveFactura = async (payload) => {
  const {
    facId, tipo, ordId, mclId, horasManoObra, valorHora, repuestos,
    descuentoPorcentaje, ivaPorcentaje, creUsuario,
  } = payload;

  const calculo = calcularFactura({
    horasManoObra, valorHora, repuestos, descuentoPorcentaje, ivaPorcentaje,
  });

  let connection = null;
  try {
    connection = await getConnection();

    if (facId) {
      await executeQuery(
        `UPDATE tbl_facturas SET
           fac_mano_obra_horas = ?, fac_valor_hora = ?, fac_subtotal_mano_obra = ?,
           fac_subtotal_repuestos = ?, fac_subtotal = ?, fac_descuento_porcentaje = ?,
           fac_descuento_valor = ?, fac_iva_porcentaje = ?, fac_iva_valor = ?, fac_total = ?
         WHERE fac_id = ?`,
        [horasManoObra, valorHora, calculo.subtotalManoObra, calculo.subtotalRepuestos,
         calculo.subtotal, descuentoPorcentaje || 0, calculo.descuentoValor,
         ivaPorcentaje ?? IVA_COLOMBIA * 100, calculo.ivaValor, calculo.total, facId],
        connection
      );
      return { facId, ...calculo };
    }

    const numero = await generarNumeroFactura(connection, tipo);
    const result = await executeQuery(
      `INSERT INTO tbl_facturas
         (fac_numero, fac_tipo, ord_id, mcl_id, fac_mano_obra_horas, fac_valor_hora,
          fac_subtotal_mano_obra, fac_subtotal_repuestos, fac_subtotal,
          fac_descuento_porcentaje, fac_descuento_valor, fac_iva_porcentaje, fac_iva_valor,
          fac_total, cre_usuario)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [numero, tipo || "cotizacion", ordId, mclId, horasManoObra || 0, valorHora || 0,
       calculo.subtotalManoObra, calculo.subtotalRepuestos, calculo.subtotal,
       descuentoPorcentaje || 0, calculo.descuentoValor, ivaPorcentaje ?? IVA_COLOMBIA * 100,
       calculo.ivaValor, calculo.total, creUsuario],
      connection
    );
    return { facId: result.insertId, numero, ...calculo };
  } finally {
    releaseConnection(connection);
  }
};

export const listFacturas = async ({ mclId, estado, rows = 10, first = 0 }) => {
  let connection = null;
  try {
    connection = await getConnection();
    const params = [];
    let where = "WHERE 1=1";

    if (mclId) {
      where += " AND f.mcl_id = ?";
      params.push(mclId);
    }
    if (estado) {
      where += " AND f.fac_estado = ?";
      params.push(estado);
    }

    const totalRows = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_facturas f ${where}`,
      params,
      connection
    );

    const data = await executeQuery(
      `SELECT f.fac_id AS facId, f.fac_numero AS numero, f.fac_tipo AS tipo,
              f.fac_total AS total, f.fac_estado AS estado, f.fac_fecha AS fecha,
              c.mcl_nombre AS clienteNombre, o.ord_numero AS ordenNumero
       FROM tbl_facturas f
       JOIN tbl_moto_clientes c ON c.mcl_id = f.mcl_id
       JOIN tbl_ordenes_trabajo o ON o.ord_id = f.ord_id
       ${where}
       ORDER BY f.fac_fecha DESC
       LIMIT ? OFFSET ?`,
      [...params, Number(rows), Number(first)],
      connection
    );

    return { data, total: totalRows[0]?.total ?? 0 };
  } finally {
    releaseConnection(connection);
  }
};
