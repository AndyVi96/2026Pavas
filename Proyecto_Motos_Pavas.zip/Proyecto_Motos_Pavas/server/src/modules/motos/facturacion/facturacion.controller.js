import * as facturacionService from "./facturacion.service.js";

export const calcularFacturaController = async (req, res, next) => {
  try {
    // Endpoint de sólo cálculo, sin persistir — para previsualización en vivo
    const result = facturacionService.calcularFactura(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const saveFacturaController = async (req, res, next) => {
  try {
    const result = await facturacionService.saveFactura(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const listFacturasController = async (req, res, next) => {
  try {
    const { mclId, estado, rows, first } = req.body;
    const result = await facturacionService.listFacturas({ mclId, estado, rows, first });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
