import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  calcularFacturaController,
  saveFacturaController,
  listFacturasController,
} from "./facturacion.controller.js";

const facturacionRoutes = express.Router();

facturacionRoutes.post("/calcular_factura", verifyToken, calcularFacturaController);
facturacionRoutes.post("/save_factura", verifyToken, saveFacturaController);
facturacionRoutes.post("/list_facturas", verifyToken, listFacturasController);

export default facturacionRoutes;
