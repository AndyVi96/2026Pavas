import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  listOrdenesController,
  saveOrdenController,
  saveTareaController,
  toggleTareaController,
  getTareasOrdenController,
  getCargaMecanicosController,
} from "./ordenes.controller.js";

const ordenesRoutes = express.Router();

ordenesRoutes.post("/list_ordenes", verifyToken, listOrdenesController);
ordenesRoutes.post("/save_orden", verifyToken, saveOrdenController);
ordenesRoutes.post("/save_tarea", verifyToken, saveTareaController);
ordenesRoutes.put("/toggle_tarea", verifyToken, toggleTareaController);
ordenesRoutes.get("/tareas_orden", verifyToken, getTareasOrdenController);
ordenesRoutes.get("/carga_mecanicos", verifyToken, getCargaMecanicosController);

export default ordenesRoutes;
