import * as ordenesService from "./ordenes.service.js";

export const listOrdenesController = async (req, res, next) => {
  try {
    const { estadoId, mecanicoId, rows, first } = req.body;
    const result = await ordenesService.listOrdenes({ estadoId, mecanicoId, rows, first });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const saveOrdenController = async (req, res, next) => {
  try {
    const result = await ordenesService.saveOrden(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const saveTareaController = async (req, res, next) => {
  try {
    const result = await ordenesService.saveTarea(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const toggleTareaController = async (req, res, next) => {
  try {
    const result = await ordenesService.toggleTarea(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const getTareasOrdenController = async (req, res, next) => {
  try {
    const { ordId } = req.query;
    const result = await ordenesService.getTareasOrden({ ordId });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const getCargaMecanicosController = async (req, res, next) => {
  try {
    const result = await ordenesService.getCargaMecanicos();
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
