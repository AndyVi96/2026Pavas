import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

// === Math: genera el consecutivo de la orden (OT-2026-00001) ===
const generarNumeroOrden = async (connection) => {
  const anio = new Date().getFullYear();
  const rows = await executeQuery(
    `SELECT COUNT(*) AS total FROM tbl_ordenes_trabajo WHERE ord_numero LIKE ?`,
    [`OT-${anio}-%`],
    connection
  );
  const siguiente = (rows[0]?.total ?? 0) + 1;
  // Math.min asegura que nunca se rompa el padStart aunque el taller crezca mucho
  const consecutivo = String(siguiente).padStart(5, "0");
  return `OT-${anio}-${consecutivo}`;
};

export const listOrdenes = async ({ estadoId, mecanicoId, rows = 10, first = 0 }) => {
  let connection = null;
  try {
    connection = await getConnection();
    const params = [];
    let where = "WHERE o.sta_id != 3";

    if (estadoId) {
      where += " AND o.eso_id = ?";
      params.push(estadoId);
    }
    if (mecanicoId) {
      where += " AND o.mmc_id = ?";
      params.push(mecanicoId);
    }

    const totalRows = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_ordenes_trabajo o ${where}`,
      params,
      connection
    );

    const data = await executeQuery(
      `SELECT o.ord_id AS ordId, o.ord_numero AS numero, o.eso_id AS estadoId,
              e.eso_nombre AS estadoNombre, e.eso_color AS estadoColor,
              o.ord_tipo_servicio AS tipoServicio, o.ord_prioridad AS prioridad,
              o.ord_descripcion AS descripcion, o.ord_horas_estimadas AS horasEstimadas,
              o.ord_horas_invertidas AS horasInvertidas,
              o.ord_fecha_inicio AS fechaInicio, o.ord_fecha_estimada_fin AS fechaEstimadaFin,
              o.ord_fecha_fin_real AS fechaFinReal,
              m.mot_placa AS placa, m.mot_marca AS marca, m.mot_linea AS linea,
              c.mcl_nombre AS clienteNombre, o.mmc_id AS mecanicoId
       FROM tbl_ordenes_trabajo o
       JOIN tbl_motocicletas m ON m.mot_id = o.mot_id
       JOIN tbl_moto_clientes c ON c.mcl_id = m.mcl_id
       JOIN tbl_moto_estados_orden e ON e.eso_id = o.eso_id
       ${where}
       ORDER BY o.cre_fecha DESC
       LIMIT ? OFFSET ?`,
      [...params, Number(rows), Number(first)],
      connection
    );

    // Enriquecemos cada orden con sus tareas para calcular el % de avance
    for (const orden of data) {
      const tareas = await executeQuery(
        `SELECT ota_completada AS completada FROM tbl_orden_tareas WHERE ord_id = ?`,
        [orden.ordId],
        connection
      );
      orden.avance = calcularAvance(tareas, orden.horasEstimadas, orden.horasInvertidas);
      orden.tiempoRestanteHoras = calcularTiempoRestante(orden.horasEstimadas, orden.horasInvertidas);
    }

    return { data, total: totalRows[0]?.total ?? 0 };
  } finally {
    releaseConnection(connection);
  }
};

// === Math: % de avance de la orden ===
// Si hay checklist de tareas, se prioriza (más preciso); si no, se usa horas.
const calcularAvance = (tareas, horasEstimadas, horasInvertidas) => {
  if (tareas && tareas.length > 0) {
    const terminadas = tareas.filter((t) => Number(t.completada) === 1).length;
    return Math.round((terminadas / tareas.length) * 100);
  }
  if (horasEstimadas && Number(horasEstimadas) > 0) {
    const avance = (Number(horasInvertidas) / Number(horasEstimadas)) * 100;
    return Math.min(100, Math.round(avance)); // nunca superar el 100%
  }
  return 0;
};

// === Math: tiempo restante estimado (nunca negativo) ===
const calcularTiempoRestante = (horasEstimadas, horasInvertidas) =>
  Math.max(0, Number(horasEstimadas || 0) - Number(horasInvertidas || 0));

export const saveOrden = async (orden) => {
  const {
    ordId, motId, mrcId, mmcId, esoId, tipoServicio, prioridad, descripcion,
    diagnostico, horasEstimadas, horasInvertidas, fechaInicio, fechaEstimadaFin,
    fechaFinReal, creUsuario,
  } = orden;

  let connection = null;
  try {
    connection = await getConnection();

    if (ordId) {
      await executeQuery(
        `UPDATE tbl_ordenes_trabajo SET
           mmc_id = ?, eso_id = ?, ord_tipo_servicio = ?, ord_prioridad = ?, ord_descripcion = ?,
           ord_diagnostico = ?, ord_horas_estimadas = ?, ord_horas_invertidas = ?,
           ord_fecha_inicio = ?, ord_fecha_estimada_fin = ?, ord_fecha_fin_real = ?
         WHERE ord_id = ?`,
        [mmcId, esoId, tipoServicio, prioridad, descripcion, diagnostico,
         horasEstimadas, horasInvertidas, fechaInicio, fechaEstimadaFin, fechaFinReal, ordId],
        connection
      );
      return { ordId };
    }

    const numero = await generarNumeroOrden(connection);
    const result = await executeQuery(
      `INSERT INTO tbl_ordenes_trabajo
         (ord_numero, mot_id, mrc_id, mmc_id, eso_id, ord_tipo_servicio, ord_prioridad,
          ord_descripcion, ord_diagnostico, ord_horas_estimadas, ord_fecha_inicio,
          ord_fecha_estimada_fin, cre_usuario)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [numero, motId, mrcId || null, mmcId || null, esoId || 1, tipoServicio || "correctivo",
       prioridad || "media", descripcion, diagnostico, horasEstimadas || 0,
       fechaInicio || new Date(), fechaEstimadaFin || null, creUsuario],
      connection
    );
    return { ordId: result.insertId, numero };
  } finally {
    releaseConnection(connection);
  }
};

export const toggleTarea = async ({ otaId, completada }) => {
  let connection = null;
  try {
    connection = await getConnection();
    await executeQuery(
      `UPDATE tbl_orden_tareas SET ota_completada = ? WHERE ota_id = ?`,
      [completada ? 1 : 0, otaId],
      connection
    );
    return { otaId };
  } finally {
    releaseConnection(connection);
  }
};

export const saveTarea = async ({ ordId, descripcion, horas }) => {
  let connection = null;
  try {
    connection = await getConnection();
    const result = await executeQuery(
      `INSERT INTO tbl_orden_tareas (ord_id, ota_descripcion, ota_horas) VALUES (?, ?, ?)`,
      [ordId, descripcion, horas || 0],
      connection
    );
    return { otaId: result.insertId };
  } finally {
    releaseConnection(connection);
  }
};

export const getTareasOrden = async ({ ordId }) => {
  let connection = null;
  try {
    connection = await getConnection();
    return await executeQuery(
      `SELECT ota_id AS otaId, ota_descripcion AS descripcion,
              ota_completada AS completada, ota_horas AS horas
       FROM tbl_orden_tareas WHERE ord_id = ? ORDER BY ota_id ASC`,
      [ordId],
      connection
    );
  } finally {
    releaseConnection(connection);
  }
};

// === Math: carga de trabajo de mecánicos (para asignación balanceada) ===
export const getCargaMecanicos = async () => {
  let connection = null;
  try {
    connection = await getConnection();
    const mecanicos = await executeQuery(
      `SELECT mmc.mmc_id AS mmcId, mmc.mmc_capacidad AS capacidad,
              CONCAT(IFNULL(u.use_name,''), ' ', IFNULL(u.use_last_name,'')) AS nombre,
              (SELECT COUNT(*) FROM tbl_ordenes_trabajo o
                 WHERE o.mmc_id = mmc.mmc_id AND o.sta_id != 3
                   AND o.eso_id NOT IN (7, 8, 9)) AS ordenesAsignadas
       FROM tbl_moto_mecanicos mmc
       JOIN tbl_users u ON u.use_id = mmc.use_id
       WHERE mmc.sta_id != 3`,
      [],
      connection
    );

    return mecanicos.map((m) => ({
      ...m,
      // % de carga; Math.min evita pasar de 100% en el indicador visual aunque esté sobrecargado
      cargaPorcentaje: Math.min(100, Math.round((m.ordenesAsignadas / (m.capacidad || 1)) * 100)),
      sobrecargado: m.ordenesAsignadas > m.capacidad,
    }));
  } finally {
    releaseConnection(connection);
  }
};
