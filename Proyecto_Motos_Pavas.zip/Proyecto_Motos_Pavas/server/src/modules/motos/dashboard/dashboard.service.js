import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

export const getIndicadores = async () => {
  let connection = null;
  try {
    connection = await getConnection();

    const [{ total: totalMotos }] = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_motocicletas WHERE sta_id != 3`, [], connection
    );
    const [{ total: totalClientes }] = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_moto_clientes WHERE sta_id != 3`, [], connection
    );
    const [{ pendientes }] = await executeQuery(
      `SELECT COUNT(*) AS pendientes FROM tbl_ordenes_trabajo WHERE sta_id != 3 AND eso_id NOT IN (7,8,9)`, [], connection
    );
    const [{ entregadas }] = await executeQuery(
      `SELECT COUNT(*) AS entregadas FROM tbl_ordenes_trabajo WHERE sta_id != 3 AND eso_id = 8`, [], connection
    );
    const [{ total: totalOrdenes }] = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_ordenes_trabajo WHERE sta_id != 3`, [], connection
    );

    // Ingresos de los últimos 30 días (para promedio diario y ticket promedio)
    const facturas = await executeQuery(
      `SELECT fac_total AS total, DATE(fac_fecha) AS dia
       FROM tbl_facturas
       WHERE fac_estado != 'anulada' AND fac_fecha >= (NOW() - INTERVAL 30 DAY)`,
      [], connection
    );

    const totales = facturas.map((f) => Number(f.total));
    const ingresoTotal30d = totales.reduce((a, b) => a + b, 0);

    // === Math: promedios, máximos y mínimos de ingresos ===
    const promedioIngresoDiario = totales.length ? Math.round(ingresoTotal30d / 30) : 0;
    const ticketPromedio = totales.length ? Math.round(ingresoTotal30d / totales.length) : 0;
    const facturaMaxima = totales.length ? Math.max(...totales) : 0;
    const facturaMinima = totales.length ? Math.min(...totales) : 0;

    // === Math: porcentaje de motos entregadas vs pendientes ===
    const porcentajeEntregadas = totalOrdenes > 0 ? Math.round((entregadas / totalOrdenes) * 100) : 0;
    const porcentajePendientes = totalOrdenes > 0 ? Math.round((pendientes / totalOrdenes) * 100) : 0;

    // Servicios por día (últimos 7 días) para la gráfica de tendencia
    const ordenesPorDia = await executeQuery(
      `SELECT DATE(cre_fecha) AS dia, COUNT(*) AS total
       FROM tbl_ordenes_trabajo
       WHERE sta_id != 3 AND cre_fecha >= (NOW() - INTERVAL 7 DAY)
       GROUP BY DATE(cre_fecha)
       ORDER BY dia ASC`,
      [], connection
    );
    const conteosPorDia = ordenesPorDia.map((d) => Number(d.total));
    // Promedio de servicios diarios de la última semana
    const promedioServiciosDiarios = conteosPorDia.length
      ? Math.round((conteosPorDia.reduce((a, b) => a + b, 0) / conteosPorDia.length) * 10) / 10
      : 0;

    // Repuestos en estado crítico (para alerta destacada del dashboard)
    const [{ criticos }] = await executeQuery(
      `SELECT COUNT(*) AS criticos FROM tbl_inventario_repuestos WHERE sta_id != 3 AND inv_stock_actual <= inv_stock_minimo`,
      [], connection
    );

    return {
      totalMotos,
      totalClientes,
      totalOrdenes,
      pendientes,
      entregadas,
      porcentajeEntregadas,
      porcentajePendientes,
      ingresoTotal30d: Math.round(ingresoTotal30d),
      promedioIngresoDiario,
      ticketPromedio,
      facturaMaxima,
      facturaMinima,
      promedioServiciosDiarios,
      repuestosCriticos: criticos,
      tendenciaOrdenes: ordenesPorDia.map((d) => ({ dia: d.dia, total: Number(d.total) })),
    };
  } finally {
    releaseConnection(connection);
  }
};

// === Math: distribución de órdenes por estado (para gráfica de dona) ===
export const getDistribucionEstados = async () => {
  let connection = null;
  try {
    connection = await getConnection();
    return await executeQuery(
      `SELECT e.eso_nombre AS estado, e.eso_color AS color, COUNT(o.ord_id) AS total
       FROM tbl_moto_estados_orden e
       LEFT JOIN tbl_ordenes_trabajo o ON o.eso_id = e.eso_id AND o.sta_id != 3
       GROUP BY e.eso_id
       ORDER BY e.eso_orden ASC`,
      [], connection
    );
  } finally {
    releaseConnection(connection);
  }
};
