import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  getIndicadoresController,
  getDistribucionEstadosController,
} from "./dashboard.controller.js";

const dashboardMotosRoutes = express.Router();

dashboardMotosRoutes.get("/indicadores", verifyToken, getIndicadoresController);
dashboardMotosRoutes.get("/distribucion_estados", verifyToken, getDistribucionEstadosController);

export default dashboardMotosRoutes;
