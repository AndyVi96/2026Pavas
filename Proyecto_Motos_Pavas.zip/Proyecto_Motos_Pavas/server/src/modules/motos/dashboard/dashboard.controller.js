import * as dashboardService from "./dashboard.service.js";

export const getIndicadoresController = async (req, res, next) => {
  try {
    const result = await dashboardService.getIndicadores();
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const getDistribucionEstadosController = async (req, res, next) => {
  try {
    const result = await dashboardService.getDistribucionEstados();
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
