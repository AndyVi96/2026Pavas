import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

export const saveRecepcion = async (rec) => {
  const {
    motId, combustibleNivel, kilometraje, estadoFisico, accesorios,
    observaciones, firmaCliente, fotos, fechaEntregaEstimada, creUsuario,
  } = rec;

  let connection = null;
  try {
    connection = await getConnection();
    const result = await executeQuery(
      `INSERT INTO tbl_moto_recepcion
         (mot_id, mrc_combustible_nivel, mrc_kilometraje, mrc_estado_fisico, mrc_accesorios,
          mrc_observaciones, mrc_firma_cliente, mrc_fotos, mrc_fecha_entrega_estimada, cre_usuario)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [motId, combustibleNivel, kilometraje, estadoFisico,
       JSON.stringify(accesorios || []), observaciones, firmaCliente,
       JSON.stringify(fotos || []), fechaEntregaEstimada, creUsuario],
      connection
    );

    // Actualiza el kilometraje de la moto con el reportado en recepción
    if (kilometraje) {
      await executeQuery(
        `UPDATE tbl_motocicletas SET mot_kilometraje = ? WHERE mot_id = ?`,
        [kilometraje, motId],
        connection
      );
    }

    return { mrcId: result.insertId };
  } finally {
    releaseConnection(connection);
  }
};

// === Math: tiempo que lleva la moto en el taller y días de retraso ===
export const getTiemposRecepcion = async ({ motId }) => {
  let connection = null;
  try {
    connection = await getConnection();
    const rows = await executeQuery(
      `SELECT mrc_id AS mrcId, mrc_fecha_ingreso AS fechaIngreso,
              mrc_fecha_entrega_estimada AS fechaEntregaEstimada
       FROM tbl_moto_recepcion
       WHERE mot_id = ?
       ORDER BY mrc_fecha_ingreso DESC
       LIMIT 1`,
      [motId],
      connection
    );

    if (!rows.length) return null;

    const { mrcId, fechaIngreso, fechaEntregaEstimada } = rows[0];
    const ahora = new Date();
    const ingreso = new Date(fechaIngreso);
    const estimada = fechaEntregaEstimada ? new Date(fechaEntregaEstimada) : null;

    const msPorDia = 1000 * 60 * 60 * 24;

    // Días completos que lleva la moto en el taller (Math.floor: no contar el día parcial)
    const diasEnTaller = Math.floor((ahora - ingreso) / msPorDia);

    // Días de retraso respecto a la fecha estimada de entrega (0 si aún no se vence)
    const diasRetraso = estimada
      ? Math.max(0, Math.ceil((ahora - estimada) / msPorDia))
      : 0;

    return { mrcId, diasEnTaller, diasRetraso, fechaIngreso, fechaEntregaEstimada };
  } finally {
    releaseConnection(connection);
  }
};
