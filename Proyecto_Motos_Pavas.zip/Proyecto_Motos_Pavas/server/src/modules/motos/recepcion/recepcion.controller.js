import * as recepcionService from "./recepcion.service.js";

export const saveRecepcionController = async (req, res, next) => {
  try {
    const result = await recepcionService.saveRecepcion(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const getTiemposRecepcionController = async (req, res, next) => {
  try {
    const { motId } = req.query;
    const result = await recepcionService.getTiemposRecepcion({ motId });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
