import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  saveRecepcionController,
  getTiemposRecepcionController,
} from "./recepcion.controller.js";

const recepcionRoutes = express.Router();

recepcionRoutes.post("/save_recepcion", verifyToken, saveRecepcionController);
recepcionRoutes.get("/tiempos_recepcion", verifyToken, getTiemposRecepcionController);

export default recepcionRoutes;
