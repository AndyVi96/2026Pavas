import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  listInventarioController,
  registrarMovimientoController,
  saveRepuestoController,
} from "./inventario.controller.js";

const inventarioRoutes = express.Router();

inventarioRoutes.post("/list_inventario", verifyToken, listInventarioController);
inventarioRoutes.post("/movimiento_inventario", verifyToken, registrarMovimientoController);
inventarioRoutes.post("/save_repuesto", verifyToken, saveRepuestoController);

export default inventarioRoutes;
