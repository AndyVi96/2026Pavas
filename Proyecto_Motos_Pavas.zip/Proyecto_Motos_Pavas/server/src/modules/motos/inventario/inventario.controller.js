import * as inventarioService from "./inventario.service.js";

export const listInventarioController = async (req, res, next) => {
  try {
    const { search, soloCritico, rows, first } = req.body;
    const result = await inventarioService.listInventario({ search, soloCritico, rows, first });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const registrarMovimientoController = async (req, res, next) => {
  try {
    const result = await inventarioService.registrarMovimiento(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const saveRepuestoController = async (req, res, next) => {
  try {
    const result = await inventarioService.saveRepuesto(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
