import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

export const listInventario = async ({ search = "", soloCritico = false, rows = 10, first = 0 }) => {
  let connection = null;
  try {
    connection = await getConnection();
    const params = [];
    let where = "WHERE sta_id != 3";

    if (search) {
      where += " AND (inv_nombre LIKE ? OR inv_codigo LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }
    if (soloCritico) {
      where += " AND inv_stock_actual <= inv_stock_minimo";
    }

    const totalRows = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_inventario_repuestos ${where}`,
      params,
      connection
    );

    const data = await executeQuery(
      `SELECT inv_id AS invId, inv_codigo AS codigo, inv_nombre AS nombre,
              inv_categoria AS categoria, inv_stock_actual AS stockActual,
              inv_stock_minimo AS stockMinimo, inv_costo_unitario AS costoUnitario,
              inv_precio_venta AS precioVenta, inv_proveedor AS proveedor
       FROM tbl_inventario_repuestos
       ${where}
       ORDER BY inv_nombre ASC
       LIMIT ? OFFSET ?`,
      [...params, Number(rows), Number(first)],
      connection
    );

    // === Math: consumo diario promedio (30 días) y días estimados antes de agotarse ===
    for (const item of data) {
      const consumo = await executeQuery(
        `SELECT COALESCE(SUM(imv_cantidad), 0) AS totalSalidas
         FROM tbl_inventario_movimientos
         WHERE inv_id = ? AND imv_tipo = 'salida' AND imv_fecha >= (NOW() - INTERVAL 30 DAY)`,
        [item.invId],
        connection
      );

      const totalSalidas = Number(consumo[0]?.totalSalidas || 0);
      const consumoDiarioPromedio = totalSalidas / 30; // promedio simple de los últimos 30 días

      item.consumoDiarioPromedio = Math.round(consumoDiarioPromedio * 100) / 100; // 2 decimales
      item.diasEstimadosAntesDeAgotarse = consumoDiarioPromedio > 0
        ? Math.ceil(item.stockActual / consumoDiarioPromedio)
        : null; // sin consumo reciente no se puede estimar
      item.esCritico = item.stockActual <= item.stockMinimo;
    }

    return { data, total: totalRows[0]?.total ?? 0 };
  } finally {
    releaseConnection(connection);
  }
};

export const registrarMovimiento = async ({ invId, ordId, tipo, cantidad, nota, creUsuario }) => {
  let connection = null;
  try {
    connection = await getConnection();

    await executeQuery(
      `INSERT INTO tbl_inventario_movimientos (inv_id, ord_id, imv_tipo, imv_cantidad, imv_nota, cre_usuario)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [invId, ordId || null, tipo, cantidad, nota, creUsuario],
      connection
    );

    // Actualiza el stock actual: suma en entradas/ajustes positivos, resta en salidas
    const delta = tipo === "salida" ? -Math.abs(cantidad) : Math.abs(cantidad);
    await executeQuery(
      `UPDATE tbl_inventario_repuestos SET inv_stock_actual = GREATEST(0, inv_stock_actual + ?) WHERE inv_id = ?`,
      [delta, invId],
      connection
    );

    return { ok: true };
  } finally {
    releaseConnection(connection);
  }
};

export const saveRepuesto = async (rep) => {
  const {
    invId, codigo, nombre, categoria, stockActual, stockMinimo,
    costoUnitario, precioVenta, proveedor,
  } = rep;

  let connection = null;
  try {
    connection = await getConnection();

    if (invId) {
      await executeQuery(
        `UPDATE tbl_inventario_repuestos SET
           inv_codigo = ?, inv_nombre = ?, inv_categoria = ?, inv_stock_actual = ?,
           inv_stock_minimo = ?, inv_costo_unitario = ?, inv_precio_venta = ?, inv_proveedor = ?
         WHERE inv_id = ?`,
        [codigo, nombre, categoria, stockActual, stockMinimo, costoUnitario, precioVenta, proveedor, invId],
        connection
      );
      return { invId };
    }

    const result = await executeQuery(
      `INSERT INTO tbl_inventario_repuestos
         (inv_codigo, inv_nombre, inv_categoria, inv_stock_actual, inv_stock_minimo,
          inv_costo_unitario, inv_precio_venta, inv_proveedor)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [codigo, nombre, categoria, stockActual || 0, stockMinimo || 5, costoUnitario || 0, precioVenta || 0, proveedor],
      connection
    );
    return { invId: result.insertId };
  } finally {
    releaseConnection(connection);
  }
};
