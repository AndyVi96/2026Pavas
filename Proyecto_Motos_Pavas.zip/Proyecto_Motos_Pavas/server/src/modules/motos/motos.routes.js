import express from "express";
import clientesRoutes from "./clientes/clientes.routes.js";
import motocicletasRoutes from "./motocicletas/motocicletas.routes.js";
import recepcionRoutes from "./recepcion/recepcion.routes.js";
import ordenesRoutes from "./ordenes/ordenes.routes.js";
import inventarioRoutes from "./inventario/inventario.routes.js";
import facturacionRoutes from "./facturacion/facturacion.routes.js";
import dashboardMotosRoutes from "./dashboard/dashboard.routes.js";

// Router agregador del módulo Motos — se monta en /api/motos/*
const motosRoutes = express.Router();

motosRoutes.use("/clientes", clientesRoutes);
motosRoutes.use("/motocicletas", motocicletasRoutes);
motosRoutes.use("/recepcion", recepcionRoutes);
motosRoutes.use("/ordenes", ordenesRoutes);
motosRoutes.use("/inventario", inventarioRoutes);
motosRoutes.use("/facturacion", facturacionRoutes);
motosRoutes.use("/dashboard", dashboardMotosRoutes);

export default motosRoutes;
