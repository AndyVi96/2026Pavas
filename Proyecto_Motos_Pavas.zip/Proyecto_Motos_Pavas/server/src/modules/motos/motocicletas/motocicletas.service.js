import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

// Intervalo estándar de mantenimiento preventivo por kilometraje (parametrizable
// por tipo de moto a futuro; hoy usamos un valor fijo del taller).
const INTERVALO_MANTENIMIENTO_KM = 5000;

export const listMotocicletas = async ({ search = "", mclId, rows = 10, first = 0 }) => {
  let connection = null;
  try {
    connection = await getConnection();
    const params = [];
    let where = "WHERE m.sta_id != 3";

    if (mclId) {
      where += " AND m.mcl_id = ?";
      params.push(mclId);
    }
    if (search) {
      where += " AND (m.mot_placa LIKE ? OR m.mot_marca LIKE ? OR m.mot_linea LIKE ? OR c.mcl_nombre LIKE ?)";
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    const totalRows = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_motocicletas m JOIN tbl_moto_clientes c ON c.mcl_id = m.mcl_id ${where}`,
      params,
      connection
    );

    const data = await executeQuery(
      `SELECT m.mot_id AS motId, m.mot_marca AS marca, m.mot_linea AS linea,
              m.mot_modelo_anio AS modeloAnio, m.mot_cilindraje AS cilindraje,
              m.mot_color AS color, m.mot_placa AS placa, m.mot_vin AS vin,
              m.mot_motor_serial AS motorSerial, m.mot_kilometraje AS kilometraje,
              m.mot_proximo_mantenimiento_km AS proximoMantenimientoKm,
              m.mot_fecha_proximo_mantenimiento AS fechaProximoMantenimiento,
              m.mcl_id AS mclId, c.mcl_nombre AS clienteNombre, c.mcl_telefono AS clienteTelefono
       FROM tbl_motocicletas m
       JOIN tbl_moto_clientes c ON c.mcl_id = m.mcl_id
       ${where}
       ORDER BY m.cre_fecha DESC
       LIMIT ? OFFSET ?`,
      [...params, Number(rows), Number(first)],
      connection
    );

    return { data, total: totalRows[0]?.total ?? 0 };
  } finally {
    releaseConnection(connection);
  }
};

export const saveMotocicleta = async (moto) => {
  const {
    motId, mclId, marca, linea, modeloAnio, cilindraje, color, placa, vin,
    motorSerial, kilometraje, creUsuario,
  } = moto;

  // === Math: cálculo automático del próximo mantenimiento preventivo ===
  const km = Number(kilometraje) || 0;
  const proximoMantenimientoKm = km + INTERVALO_MANTENIMIENTO_KM;
  const fechaProximoMantenimiento = new Date();
  fechaProximoMantenimiento.setMonth(fechaProximoMantenimiento.getMonth() + 6);

  let connection = null;
  try {
    connection = await getConnection();

    if (motId) {
      await executeQuery(
        `UPDATE tbl_motocicletas SET
           mcl_id = ?, mot_marca = ?, mot_linea = ?, mot_modelo_anio = ?, mot_cilindraje = ?,
           mot_color = ?, mot_placa = ?, mot_vin = ?, mot_motor_serial = ?, mot_kilometraje = ?,
           mot_proximo_mantenimiento_km = ?, mot_fecha_proximo_mantenimiento = ?
         WHERE mot_id = ?`,
        [mclId, marca, linea, modeloAnio, cilindraje, color, placa, vin, motorSerial, km,
         proximoMantenimientoKm, fechaProximoMantenimiento, motId],
        connection
      );
      return { motId, proximoMantenimientoKm };
    }

    const result = await executeQuery(
      `INSERT INTO tbl_motocicletas
         (mcl_id, mot_marca, mot_linea, mot_modelo_anio, mot_cilindraje, mot_color, mot_placa,
          mot_vin, mot_motor_serial, mot_kilometraje, mot_proximo_mantenimiento_km,
          mot_fecha_proximo_mantenimiento, cre_usuario)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [mclId, marca, linea, modeloAnio, cilindraje, color, placa, vin, motorSerial, km,
       proximoMantenimientoKm, fechaProximoMantenimiento, creUsuario],
      connection
    );
    return { motId: result.insertId, proximoMantenimientoKm };
  } finally {
    releaseConnection(connection);
  }
};

export const deleteMotocicleta = async ({ motId }) => {
  let connection = null;
  try {
    connection = await getConnection();
    await executeQuery(`UPDATE tbl_motocicletas SET sta_id = 3 WHERE mot_id = ?`, [motId], connection);
    return { motId };
  } finally {
    releaseConnection(connection);
  }
};
