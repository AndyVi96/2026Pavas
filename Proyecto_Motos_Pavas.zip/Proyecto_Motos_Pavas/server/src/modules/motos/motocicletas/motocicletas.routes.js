import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  listMotocicletasController,
  saveMotocicletaController,
  deleteMotocicletaController,
} from "./motocicletas.controller.js";

const motocicletasRoutes = express.Router();

motocicletasRoutes.post("/list_motocicletas", verifyToken, listMotocicletasController);
motocicletasRoutes.post("/save_motocicleta", verifyToken, saveMotocicletaController);
motocicletasRoutes.put("/delete_motocicleta", verifyToken, deleteMotocicletaController);

export default motocicletasRoutes;
