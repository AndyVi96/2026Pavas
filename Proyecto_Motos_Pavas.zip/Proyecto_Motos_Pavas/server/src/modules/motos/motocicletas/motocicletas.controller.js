import * as motosService from "./motocicletas.service.js";

export const listMotocicletasController = async (req, res, next) => {
  try {
    const { search, mclId, rows, first } = req.body;
    const result = await motosService.listMotocicletas({ search, mclId, rows, first });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const saveMotocicletaController = async (req, res, next) => {
  try {
    const result = await motosService.saveMotocicleta(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteMotocicletaController = async (req, res, next) => {
  try {
    const { motId } = req.body;
    const result = await motosService.deleteMotocicleta({ motId });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
