import * as clientesService from "./clientes.service.js";

export const listClientesController = async (req, res, next) => {
  try {
    const { search, rows, first } = req.body;
    const result = await clientesService.listClientes({ search, rows, first });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const getClienteHistorialController = async (req, res, next) => {
  try {
    const { mclId } = req.query;
    const result = await clientesService.getClienteHistorial({ mclId });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const saveClienteController = async (req, res, next) => {
  try {
    const result = await clientesService.saveCliente(req.body);
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteClienteController = async (req, res, next) => {
  try {
    const { mclId } = req.body;
    const result = await clientesService.deleteCliente({ mclId });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
};
