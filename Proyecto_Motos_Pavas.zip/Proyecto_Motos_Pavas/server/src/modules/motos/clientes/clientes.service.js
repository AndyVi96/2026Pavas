import {
  getConnection,
  releaseConnection,
  executeQuery,
} from "../../../common/configs/db.config.js";

export const listClientes = async ({ search = "", rows = 10, first = 0 }) => {
  let connection = null;
  try {
    connection = await getConnection();

    const params = [];
    let where = "WHERE sta_id != 3";
    if (search) {
      where += ` AND (mcl_nombre LIKE ? OR mcl_identificacion LIKE ? OR mcl_telefono LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const totalRows = await executeQuery(
      `SELECT COUNT(*) AS total FROM tbl_moto_clientes ${where}`,
      params,
      connection
    );

    const data = await executeQuery(
      `SELECT mcl_id AS mclId, mcl_nombre AS nombre, mcl_identificacion AS identificacion,
              mcl_telefono AS telefono, mcl_email AS email, mcl_direccion AS direccion,
              mcl_ciudad AS ciudad, mcl_notas AS notas
       FROM tbl_moto_clientes
       ${where}
       ORDER BY mcl_nombre ASC
       LIMIT ? OFFSET ?`,
      [...params, Number(rows), Number(first)],
      connection
    );

    return { data, total: totalRows[0]?.total ?? 0 };
  } finally {
    releaseConnection(connection);
  }
};

export const getClienteHistorial = async ({ mclId }) => {
  let connection = null;
  try {
    connection = await getConnection();
    // Historial completo: motos del cliente + órdenes de cada moto
    const motos = await executeQuery(
      `SELECT mot_id AS motId, mot_marca AS marca, mot_linea AS linea, mot_placa AS placa,
              mot_kilometraje AS kilometraje
       FROM tbl_motocicletas WHERE mcl_id = ? AND sta_id != 3`,
      [mclId],
      connection
    );

    const ordenes = await executeQuery(
      `SELECT o.ord_id AS ordId, o.ord_numero AS numero, o.ord_tipo_servicio AS tipoServicio,
              o.ord_fecha_inicio AS fechaInicio, o.ord_fecha_fin_real AS fechaFin,
              e.eso_nombre AS estado, m.mot_placa AS placa
       FROM tbl_ordenes_trabajo o
       JOIN tbl_motocicletas m ON m.mot_id = o.mot_id
       JOIN tbl_moto_estados_orden e ON e.eso_id = o.eso_id
       WHERE m.mcl_id = ? AND o.sta_id != 3
       ORDER BY o.cre_fecha DESC`,
      [mclId],
      connection
    );

    return { motos, ordenes };
  } finally {
    releaseConnection(connection);
  }
};

export const saveCliente = async (cliente) => {
  const {
    mclId, nombre, identificacion, telefono, email, direccion, ciudad, notas, creUsuario,
  } = cliente;

  let connection = null;
  try {
    connection = await getConnection();

    if (mclId) {
      await executeQuery(
        `UPDATE tbl_moto_clientes SET
           mcl_nombre = ?, mcl_identificacion = ?, mcl_telefono = ?, mcl_email = ?,
           mcl_direccion = ?, mcl_ciudad = ?, mcl_notas = ?
         WHERE mcl_id = ?`,
        [nombre, identificacion, telefono, email, direccion, ciudad, notas, mclId],
        connection
      );
      return { mclId };
    }

    const result = await executeQuery(
      `INSERT INTO tbl_moto_clientes
         (mcl_nombre, mcl_identificacion, mcl_telefono, mcl_email, mcl_direccion, mcl_ciudad, mcl_notas, cre_usuario)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [nombre, identificacion, telefono, email, direccion, ciudad, notas, creUsuario],
      connection
    );
    return { mclId: result.insertId };
  } finally {
    releaseConnection(connection);
  }
};

export const deleteCliente = async ({ mclId }) => {
  let connection = null;
  try {
    connection = await getConnection();
    await executeQuery(
      `UPDATE tbl_moto_clientes SET sta_id = 3 WHERE mcl_id = ?`,
      [mclId],
      connection
    );
    return { mclId };
  } finally {
    releaseConnection(connection);
  }
};
