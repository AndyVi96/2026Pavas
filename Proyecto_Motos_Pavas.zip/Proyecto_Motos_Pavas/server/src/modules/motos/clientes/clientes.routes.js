import express from "express";
import { verifyToken } from "../../../common/middlewares/authjwt.middleware.js";
import {
  listClientesController,
  getClienteHistorialController,
  saveClienteController,
  deleteClienteController,
} from "./clientes.controller.js";

const clientesRoutes = express.Router();

clientesRoutes.post("/list_clientes", verifyToken, listClientesController);
clientesRoutes.get("/historial_cliente", verifyToken, getClienteHistorialController);
clientesRoutes.post("/save_cliente", verifyToken, saveClienteController);
clientesRoutes.put("/delete_cliente", verifyToken, deleteClienteController);

export default clientesRoutes;
