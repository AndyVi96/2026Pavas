import dashboard from './dashboard';
import pages from './pages';
import utilities from './utilities';
import other from './other';
import security from './security';     // ← nuevo
import motos from './motos';           // ← módulo Taller de Motos

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
  items: [dashboard, motos, security, pages, utilities, other]
};

export default menuItems;