// assets
import {
  IconMotorbike,
  IconUsers,
  IconClipboardList,
  IconBoxSeam,
  IconFileInvoice,
  IconGauge
} from '@tabler/icons-react';

// constant
const icons = { IconMotorbike, IconUsers, IconClipboardList, IconBoxSeam, IconFileInvoice, IconGauge };

// ==============================|| MOTOS MENU ITEMS ||============================== //

const motos = {
  id: 'motos',
  title: 'Taller de Motos',
  type: 'group',
  children: [
    {
      id: 'motos-collapse',
      title: 'Taller de Motos',
      type: 'collapse',
      icon: icons.IconMotorbike,
      children: [
        {
          id: 'motos-dashboard',
          title: 'Dashboard',
          type: 'item',
          url: '/motos/dashboard',
          icon: icons.IconGauge,
          breadcrumbs: true
        },
        {
          id: 'motos-clientes',
          title: 'Clientes',
          type: 'item',
          url: '/motos/clientes',
          icon: icons.IconUsers,
          breadcrumbs: true
        },
        {
          id: 'motos-motocicletas',
          title: 'Motocicletas',
          type: 'item',
          url: '/motos/motocicletas',
          icon: icons.IconMotorbike,
          breadcrumbs: true
        },
        {
          id: 'motos-ordenes',
          title: 'Órdenes de trabajo',
          type: 'item',
          url: '/motos/ordenes',
          icon: icons.IconClipboardList,
          breadcrumbs: true
        },
        {
          id: 'motos-inventario',
          title: 'Inventario',
          type: 'item',
          url: '/motos/inventario',
          icon: icons.IconBoxSeam,
          breadcrumbs: true
        },
        {
          id: 'motos-facturacion',
          title: 'Facturación',
          type: 'item',
          url: '/motos/facturacion',
          icon: icons.IconFileInvoice,
          breadcrumbs: true
        }
      ]
    }
  ]
};

export default motos;
