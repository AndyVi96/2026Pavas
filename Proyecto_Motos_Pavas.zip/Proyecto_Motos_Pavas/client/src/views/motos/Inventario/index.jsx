import { useState, useEffect, useCallback } from 'react';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Chip from '@mui/material/Chip';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';

import { IconEdit, IconPlus } from '@tabler/icons-react';

import MainCard from 'ui-component/cards/MainCard';
import DataTable from 'ui-component/extended/DataTable';
import { listInventarioAPI, saveRepuestoAPI } from 'api/requests/motosApi';
import { showSuccess, showError, showObligatorios } from 'services/ToastService';

const emptyForm = {
  invId: null, codigo: '', nombre: '', categoria: '', stockActual: 0,
  stockMinimo: 5, costoUnitario: 0, precioVenta: 0, proveedor: ''
};

export default function MotosInventario() {
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState('');
  const [soloCritico, setSoloCritico] = useState(false);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const fetchInventario = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await listInventarioAPI({ search, soloCritico, rows: rowsPerPage, first: page * rowsPerPage });
      setRows(data.data ?? []);
      setTotal(data.total ?? 0);
    } catch (err) {
      console.error('Error cargando inventario:', err);
    } finally {
      setLoading(false);
    }
  }, [search, soloCritico, page, rowsPerPage]);

  useEffect(() => {
    fetchInventario();
  }, [fetchInventario]);

  const handleNew = () => {
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setForm({ ...emptyForm, ...row });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.codigo || !form.nombre) {
      showObligatorios(false);
      return;
    }
    setSaving(true);
    try {
      await saveRepuestoAPI(form);
      showSuccess('Repuesto guardado correctamente');
      setDialogOpen(false);
      fetchInventario();
    } catch (err) {
      console.error('Error guardando repuesto:', err);
      showError('No fue posible guardar el repuesto');
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    { id: 'codigo', label: 'Código' },
    { id: 'nombre', label: 'Repuesto', sortable: true },
    { id: 'categoria', label: 'Categoría', hideInCard: true },
    {
      id: 'stockActual',
      label: 'Stock',
      render: (row) => (
        <Chip
          size="small"
          label={`${row.stockActual} / mín. ${row.stockMinimo}`}
          color={row.esCritico ? 'error' : 'success'}
        />
      )
    },
    {
      id: 'diasEstimadosAntesDeAgotarse',
      label: 'Días estimados restantes',
      hideInCard: true,
      // === Math: Math.ceil(stock / consumoDiarioPromedio) resuelto en backend ===
      render: (row) =>
        row.diasEstimadosAntesDeAgotarse !== null && row.diasEstimadosAntesDeAgotarse !== undefined
          ? `${row.diasEstimadosAntesDeAgotarse} días`
          : 'Sin consumo reciente'
    },
    { id: 'precioVenta', label: 'Precio venta', render: (row) => (row.precioVenta ?? 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }) }
  ];

  const actions = (row) => [
    { label: 'Editar', icon: <IconEdit size={18} />, color: '#1976d2', command: () => handleEdit(row) }
  ];

  return (
    <MainCard
      title="Inventario de repuestos"
      secondary={
        <Button variant="contained" startIcon={<IconPlus size={18} />} onClick={handleNew}>
          Nuevo repuesto
        </Button>
      }
    >
      <Stack spacing={2}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems={{ sm: 'center' }}>
          <TextField
            label="Buscar por nombre o código"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(0);
            }}
            size="small"
            sx={{ flex: 1 }}
          />
          <FormControlLabel
            control={
              <Switch
                checked={soloCritico}
                onChange={(e) => {
                  setSoloCritico(e.target.checked);
                  setPage(0);
                }}
              />
            }
            label="Solo stock crítico"
          />
        </Stack>

        <DataTable
          columns={columns}
          rows={rows}
          total={total}
          loading={loading}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(e, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          keyExtractor={(row) => row.invId}
          actions={actions}
          cardTitleRender={(row) => row.nombre}
        />
      </Stack>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{form.invId ? 'Editar repuesto' : 'Nuevo repuesto'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Código" value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Categoría" value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Nombre del repuesto" value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Stock actual"
                value={form.stockActual}
                onChange={(e) => setForm({ ...form, stockActual: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Stock mínimo"
                value={form.stockMinimo}
                onChange={(e) => setForm({ ...form, stockMinimo: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Costo unitario"
                value={form.costoUnitario}
                onChange={(e) => setForm({ ...form, costoUnitario: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Precio de venta"
                value={form.precioVenta}
                onChange={(e) => setForm({ ...form, precioVenta: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Proveedor" value={form.proveedor} onChange={(e) => setForm({ ...form, proveedor: e.target.value })} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancelar</Button>
          <Button variant="contained" disabled={saving} onClick={handleSave}>
            {saving ? 'Guardando…' : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </MainCard>
  );
}
