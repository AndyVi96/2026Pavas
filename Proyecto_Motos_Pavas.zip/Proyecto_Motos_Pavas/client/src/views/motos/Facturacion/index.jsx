import { useState, useMemo } from 'react';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import MenuItem from '@mui/material/MenuItem';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

import { IconPlus, IconTrash } from '@tabler/icons-react';

import MainCard from 'ui-component/cards/MainCard';
import { gridSpacing } from 'store/constant';
import { saveFacturaAPI } from 'api/requests/motosApi';
import { showSuccess, showError, showObligatorios } from 'services/ToastService';

const currency = (value) =>
  (value ?? 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });

let repuestoUid = 0;

export default function MotosFacturacion() {
  const [ordId, setOrdId] = useState('');
  const [mclId, setMclId] = useState('');
  const [tipo, setTipo] = useState('cotizacion');

  const [horasManoObra, setHorasManoObra] = useState(0);
  const [valorHora, setValorHora] = useState(25000);
  const [descuentoPorcentaje, setDescuentoPorcentaje] = useState(0);
  const [ivaPorcentaje, setIvaPorcentaje] = useState(19);

  const [repuestos, setRepuestos] = useState([
    { uid: repuestoUid++, nombre: '', cantidad: 1, precioUnitario: 0 }
  ]);

  const [saving, setSaving] = useState(false);

  const handleAddRepuesto = () => {
    setRepuestos((prev) => [...prev, { uid: repuestoUid++, nombre: '', cantidad: 1, precioUnitario: 0 }]);
  };

  const handleRemoveRepuesto = (uid) => {
    setRepuestos((prev) => prev.filter((r) => r.uid !== uid));
  };

  const handleChangeRepuesto = (uid, field, value) => {
    setRepuestos((prev) => prev.map((r) => (r.uid === uid ? { ...r, [field]: value } : r)));
  };

  // ==========================================================================
  // === Math: la misma fórmula exacta que usa el backend (facturacion.service.js
  //     -> calcularFactura), para que la previsualización sea instantánea sin
  //     esperar una respuesta de red mientras el usuario escribe.
  //     El backend SIEMPRE vuelve a calcular y persiste su propio resultado:
  //     el frontend nunca es la fuente de verdad del total facturado.
  // ==========================================================================
  const calculo = useMemo(() => {
    const horas = Number(horasManoObra) || 0;
    const valorH = Number(valorHora) || 0;

    const subtotalManoObra = horas * valorH;

    const subtotalRepuestos = repuestos.reduce(
      (acc, r) => acc + (Number(r.cantidad) || 0) * (Number(r.precioUnitario) || 0),
      0
    );

    const subtotal = subtotalManoObra + subtotalRepuestos;
    const descuentoValor = subtotal * (Number(descuentoPorcentaje) / 100);
    const baseConDescuento = subtotal - descuentoValor;
    const ivaValor = baseConDescuento * (Number(ivaPorcentaje) / 100);

    // Math.round: nunca se factura un valor con centavos imposibles de cobrar en efectivo
    const total = Math.round(baseConDescuento + ivaValor);

    return {
      subtotalManoObra: Math.round(subtotalManoObra),
      subtotalRepuestos: Math.round(subtotalRepuestos),
      subtotal: Math.round(subtotal),
      descuentoValor: Math.round(descuentoValor),
      ivaValor: Math.round(ivaValor),
      total
    };
  }, [horasManoObra, valorHora, repuestos, descuentoPorcentaje, ivaPorcentaje]);

  const isValid = ordId && mclId && horasManoObra >= 0;

  const handleSave = async () => {
    if (!isValid) {
      showObligatorios(false);
      return;
    }
    setSaving(true);
    try {
      await saveFacturaAPI({
        tipo,
        ordId,
        mclId,
        horasManoObra: Number(horasManoObra),
        valorHora: Number(valorHora),
        repuestos: repuestos.map((r) => ({ cantidad: r.cantidad, precioUnitario: r.precioUnitario })),
        descuentoPorcentaje: Number(descuentoPorcentaje),
        ivaPorcentaje: Number(ivaPorcentaje)
      });
      showSuccess(tipo === 'factura' ? 'Factura generada correctamente' : 'Cotización generada correctamente');
    } catch (err) {
      console.error('Error guardando factura:', err);
      showError('No fue posible guardar el documento');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Grid container spacing={gridSpacing}>
      <Grid size={{ xs: 12, md: 7 }}>
        <MainCard title="Cotización / Factura">
          <Stack spacing={2}>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 4 }}>
                <TextField
                  select
                  fullWidth
                  label="Tipo de documento"
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value)}
                >
                  <MenuItem value="cotizacion">Cotización</MenuItem>
                  <MenuItem value="factura">Factura</MenuItem>
                </TextField>
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <TextField
                  fullWidth
                  label="ID Orden de trabajo"
                  value={ordId}
                  onChange={(e) => setOrdId(e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <TextField
                  fullWidth
                  label="ID Cliente"
                  value={mclId}
                  onChange={(e) => setMclId(e.target.value)}
                />
              </Grid>
            </Grid>

            <Divider textAlign="left">Mano de obra</Divider>
            <Grid container spacing={2}>
              <Grid size={{ xs: 6 }}>
                <TextField
                  fullWidth
                  type="number"
                  label="Horas trabajadas"
                  value={horasManoObra}
                  onChange={(e) => setHorasManoObra(e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 6 }}>
                <TextField
                  fullWidth
                  type="number"
                  label="Valor por hora"
                  value={valorHora}
                  onChange={(e) => setValorHora(e.target.value)}
                />
              </Grid>
            </Grid>

            <Divider textAlign="left">Repuestos</Divider>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Repuesto</TableCell>
                  <TableCell align="center" width={90}>Cant.</TableCell>
                  <TableCell align="right" width={140}>Precio unit.</TableCell>
                  <TableCell align="right" width={110}>Subtotal</TableCell>
                  <TableCell width={40} />
                </TableRow>
              </TableHead>
              <TableBody>
                {repuestos.map((r) => (
                  <TableRow key={r.uid}>
                    <TableCell>
                      <TextField
                        fullWidth
                        size="small"
                        variant="standard"
                        placeholder="Nombre del repuesto"
                        value={r.nombre}
                        onChange={(e) => handleChangeRepuesto(r.uid, 'nombre', e.target.value)}
                      />
                    </TableCell>
                    <TableCell align="center">
                      <TextField
                        size="small"
                        variant="standard"
                        type="number"
                        value={r.cantidad}
                        onChange={(e) => handleChangeRepuesto(r.uid, 'cantidad', e.target.value)}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <TextField
                        size="small"
                        variant="standard"
                        type="number"
                        value={r.precioUnitario}
                        onChange={(e) => handleChangeRepuesto(r.uid, 'precioUnitario', e.target.value)}
                      />
                    </TableCell>
                    <TableCell align="right">
                      {currency((Number(r.cantidad) || 0) * (Number(r.precioUnitario) || 0))}
                    </TableCell>
                    <TableCell>
                      <IconButton size="small" color="error" onClick={() => handleRemoveRepuesto(r.uid)}>
                        <IconTrash size={16} />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <Button size="small" startIcon={<IconPlus size={16} />} onClick={handleAddRepuesto} sx={{ alignSelf: 'flex-start' }}>
              Agregar repuesto
            </Button>

            <Divider textAlign="left">Descuentos e impuestos</Divider>
            <Grid container spacing={2}>
              <Grid size={{ xs: 6 }}>
                <TextField
                  fullWidth
                  type="number"
                  label="Descuento (%)"
                  value={descuentoPorcentaje}
                  onChange={(e) => setDescuentoPorcentaje(e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 6 }}>
                <TextField
                  fullWidth
                  type="number"
                  label="IVA (%)"
                  value={ivaPorcentaje}
                  onChange={(e) => setIvaPorcentaje(e.target.value)}
                />
              </Grid>
            </Grid>

            <Button variant="contained" size="large" disabled={saving} onClick={handleSave}>
              {saving ? 'Guardando…' : tipo === 'factura' ? 'Generar factura' : 'Generar cotización'}
            </Button>
          </Stack>
        </MainCard>
      </Grid>

      <Grid size={{ xs: 12, md: 5 }}>
        <MainCard title="Resumen en tiempo real">
          <Stack spacing={1.25}>
            <Stack direction="row" justifyContent="space-between">
              <Typography color="text.secondary">Mano de obra</Typography>
              <Typography>{currency(calculo.subtotalManoObra)}</Typography>
            </Stack>
            <Stack direction="row" justifyContent="space-between">
              <Typography color="text.secondary">Repuestos</Typography>
              <Typography>{currency(calculo.subtotalRepuestos)}</Typography>
            </Stack>
            <Divider />
            <Stack direction="row" justifyContent="space-between">
              <Typography color="text.secondary">Subtotal</Typography>
              <Typography>{currency(calculo.subtotal)}</Typography>
            </Stack>
            <Stack direction="row" justifyContent="space-between">
              <Typography color="text.secondary">Descuento ({descuentoPorcentaje || 0}%)</Typography>
              <Typography color="error.main">− {currency(calculo.descuentoValor)}</Typography>
            </Stack>
            <Stack direction="row" justifyContent="space-between">
              <Typography color="text.secondary">IVA ({ivaPorcentaje || 0}%)</Typography>
              <Typography>{currency(calculo.ivaValor)}</Typography>
            </Stack>
            <Divider />
            <Stack direction="row" justifyContent="space-between">
              <Typography variant="h4">Total a pagar</Typography>
              <Typography variant="h4" color="primary.main">
                {currency(calculo.total)}
              </Typography>
            </Stack>
            <Typography variant="caption" color="text.secondary">
              El total se redondea al peso (Math.round) para que siempre sea un valor cobrable en efectivo.
            </Typography>
          </Stack>
        </MainCard>
      </Grid>
    </Grid>
  );
}
