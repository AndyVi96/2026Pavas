import { useEffect, useState, useCallback } from 'react';
import Grid from '@mui/material/Grid';
import Chart from 'react-apexcharts';

import MainCard from 'ui-component/cards/MainCard';
import CardGrid from 'ui-component/cards/CardGrid';
import { gridSpacing } from 'store/constant';

import {
  IconMotorbike,
  IconUsers,
  IconClipboardCheck,
  IconClock,
  IconCash,
  IconAlertTriangle
} from '@tabler/icons-react';

import { getIndicadoresMotosAPI, getDistribucionEstadosAPI } from 'api/requests/motosApi';

const currency = (value) =>
  (value ?? 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });

export default function MotosDashboard() {
  const [indicadores, setIndicadores] = useState(null);
  const [distribucion, setDistribucion] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: indData }, { data: distData }] = await Promise.all([
        getIndicadoresMotosAPI(),
        getDistribucionEstadosAPI()
      ]);
      setIndicadores(indData);
      setDistribucion(distData ?? []);
    } catch (err) {
      console.error('Error cargando dashboard de motos:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const cards = indicadores
    ? [
        {
          titulo: 'Motocicletas registradas',
          icono: <IconMotorbike size={22} />,
          backgroundColor: '#eef2ff',
          backgroundColorIcon: '#4f46e5',
          contador: indicadores.totalMotos
        },
        {
          titulo: 'Clientes',
          icono: <IconUsers size={22} />,
          backgroundColor: '#f0fdf4',
          backgroundColorIcon: '#16a34a',
          contador: indicadores.totalClientes
        },
        {
          titulo: 'Servicios pendientes',
          icono: <IconClock size={22} />,
          backgroundColor: '#fffbeb',
          backgroundColorIcon: '#d97706',
          contador: indicadores.pendientes,
          // Math.round((pendientes/total)*100) ya viene calculado del backend
          subtitulo: `${indicadores.porcentajePendientes}% del total de órdenes`
        },
        {
          titulo: 'Servicios entregados',
          icono: <IconClipboardCheck size={22} />,
          backgroundColor: '#f0fdfa',
          backgroundColorIcon: '#0d9488',
          contador: indicadores.entregadas,
          subtitulo: `${indicadores.porcentajeEntregadas}% del total de órdenes`
        },
        {
          titulo: 'Ingresos (30 días)',
          icono: <IconCash size={22} />,
          backgroundColor: '#faf5ff',
          backgroundColorIcon: '#9333ea',
          contador: indicadores.ingresoTotal30d,
          subtitulo: `Promedio diario: ${currency(indicadores.promedioIngresoDiario)} · Ticket promedio: ${currency(indicadores.ticketPromedio)}`
        },
        {
          titulo: 'Repuestos en stock crítico',
          icono: <IconAlertTriangle size={22} />,
          backgroundColor: '#fef2f2',
          backgroundColorIcon: '#dc2626',
          contador: indicadores.repuestosCriticos,
          subtitulo: 'Requieren reposición pronto'
        }
      ]
    : [];

  // Tendencia de órdenes creadas (últimos 7 días) — line chart
  const tendenciaSeries = [
    { name: 'Órdenes creadas', data: (indicadores?.tendenciaOrdenes ?? []).map((d) => d.total) }
  ];
  const tendenciaCategories = (indicadores?.tendenciaOrdenes ?? []).map((d) => d.dia);

  const lineChartOptions = {
    chart: { toolbar: { show: false }, id: 'tendencia-ordenes' },
    xaxis: { categories: tendenciaCategories },
    colors: ['#4f46e5'],
    stroke: { curve: 'smooth', width: 3 },
    dataLabels: { enabled: false },
    grid: { strokeDashArray: 4 }
  };

  // Distribución de órdenes por estado — donut chart
  const donutSeries = distribucion.map((d) => Number(d.total));
  const donutOptions = {
    labels: distribucion.map((d) => d.estado),
    colors: distribucion.map((d) => d.color),
    legend: { position: 'bottom' },
    dataLabels: { enabled: true }
  };

  return (
    <Grid container spacing={gridSpacing}>
      {cards.map((card, index) => (
        <Grid key={index} size={{ lg: 4, md: 6, sm: 6, xs: 12 }}>
          <CardGrid {...card} />
        </Grid>
      ))}

      <Grid size={{ xs: 12, md: 7 }}>
        <MainCard title="Órdenes de trabajo creadas — últimos 7 días">
          {!loading && (
            <Chart options={lineChartOptions} series={tendenciaSeries} type="line" height={320} />
          )}
        </MainCard>
      </Grid>

      <Grid size={{ xs: 12, md: 5 }}>
        <MainCard title="Distribución de órdenes por estado">
          {!loading && donutSeries.length > 0 && (
            <Chart options={donutOptions} series={donutSeries} type="donut" height={320} />
          )}
        </MainCard>
      </Grid>
    </Grid>
  );
}
