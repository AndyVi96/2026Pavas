import { useState, useEffect, useCallback } from 'react';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Chip from '@mui/material/Chip';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';

import { IconEdit, IconTrash, IconPlus } from '@tabler/icons-react';

import MainCard from 'ui-component/cards/MainCard';
import DataTable from 'ui-component/extended/DataTable';
import { listMotocicletasAPI, saveMotocicletaAPI, deleteMotocicletaAPI } from 'api/requests/motosApi';
import { showSuccess, showError, showObligatorios } from 'services/ToastService';

const emptyForm = {
  motId: null, mclId: '', marca: '', linea: '', modeloAnio: '', cilindraje: '',
  color: '', placa: '', vin: '', motorSerial: '', kilometraje: 0
};

export default function MotosMotocicletas() {
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const fetchMotos = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await listMotocicletasAPI({ search, rows: rowsPerPage, first: page * rowsPerPage });
      setRows(data.data ?? []);
      setTotal(data.total ?? 0);
    } catch (err) {
      console.error('Error cargando motocicletas:', err);
    } finally {
      setLoading(false);
    }
  }, [search, page, rowsPerPage]);

  useEffect(() => {
    fetchMotos();
  }, [fetchMotos]);

  const handleNew = () => {
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setForm({ ...emptyForm, ...row });
    setDialogOpen(true);
  };

  const handleDelete = async (motId) => {
    try {
      await deleteMotocicletaAPI({ motId });
      showSuccess('Motocicleta eliminada');
      fetchMotos();
    } catch (err) {
      console.error('Error eliminando motocicleta:', err);
      showError('No fue posible eliminar la motocicleta');
    }
  };

  const handleSave = async () => {
    if (!form.mclId || !form.marca || !form.placa) {
      showObligatorios(false);
      return;
    }
    setSaving(true);
    try {
      await saveMotocicletaAPI(form);
      showSuccess('Motocicleta guardada correctamente');
      setDialogOpen(false);
      fetchMotos();
    } catch (err) {
      console.error('Error guardando motocicleta:', err);
      showError('No fue posible guardar la motocicleta');
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    { id: 'placa', label: 'Placa', sortable: true },
    { id: 'marca', label: 'Marca / Línea', render: (row) => `${row.marca} ${row.linea || ''}` },
    { id: 'clienteNombre', label: 'Propietario' },
    { id: 'kilometraje', label: 'Kilometraje', render: (row) => `${(row.kilometraje ?? 0).toLocaleString('es-CO')} km` },
    {
      id: 'proximoMantenimientoKm',
      label: 'Próximo mantenimiento',
      hideInCard: true,
      // Calculado en backend con Math: kilometrajeActual + 5000
      render: (row) => (
        <Chip
          size="small"
          label={row.proximoMantenimientoKm ? `${row.proximoMantenimientoKm.toLocaleString('es-CO')} km` : '—'}
          color="primary"
          variant="outlined"
        />
      )
    }
  ];

  const actions = (row) => [
    { label: 'Editar', icon: <IconEdit size={18} />, color: '#1976d2', command: () => handleEdit(row) },
    {
      label: 'Eliminar',
      icon: <IconTrash size={18} />,
      color: '#d32f2f',
      confirm: `¿Eliminar la motocicleta con placa ${row.placa}?`,
      command: () => handleDelete(row.motId)
    }
  ];

  return (
    <MainCard
      title="Motocicletas"
      secondary={
        <Button variant="contained" startIcon={<IconPlus size={18} />} onClick={handleNew}>
          Nueva motocicleta
        </Button>
      }
    >
      <Stack spacing={2}>
        <TextField
          label="Buscar por placa, marca, línea o propietario"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(0);
          }}
          size="small"
        />

        <DataTable
          columns={columns}
          rows={rows}
          total={total}
          loading={loading}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(e, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          keyExtractor={(row) => row.motId}
          actions={actions}
          cardTitleRender={(row) => `${row.placa} · ${row.marca}`}
        />
      </Stack>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{form.motId ? 'Editar motocicleta' : 'Nueva motocicleta'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="ID Cliente propietario"
                value={form.mclId}
                onChange={(e) => setForm({ ...form, mclId: e.target.value })}
                helperText="Usa el ID del cliente registrado en el módulo Clientes"
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Placa"
                value={form.placa}
                onChange={(e) => setForm({ ...form, placa: e.target.value.toUpperCase() })}
              />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
              <TextField fullWidth label="Marca" value={form.marca} onChange={(e) => setForm({ ...form, marca: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
              <TextField fullWidth label="Línea" value={form.linea} onChange={(e) => setForm({ ...form, linea: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
              <TextField
                fullWidth
                type="number"
                label="Modelo (año)"
                value={form.modeloAnio}
                onChange={(e) => setForm({ ...form, modeloAnio: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
              <TextField
                fullWidth
                type="number"
                label="Cilindraje"
                value={form.cilindraje}
                onChange={(e) => setForm({ ...form, cilindraje: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
              <TextField fullWidth label="Color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
              <TextField
                fullWidth
                type="number"
                label="Kilometraje actual"
                value={form.kilometraje}
                onChange={(e) => setForm({ ...form, kilometraje: e.target.value })}
                helperText="El próximo mantenimiento se calcula automáticamente (+5.000 km)"
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField fullWidth label="VIN" value={form.vin} onChange={(e) => setForm({ ...form, vin: e.target.value })} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Serial de motor"
                value={form.motorSerial}
                onChange={(e) => setForm({ ...form, motorSerial: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancelar</Button>
          <Button variant="contained" disabled={saving} onClick={handleSave}>
            {saving ? 'Guardando…' : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </MainCard>
  );
}
