import { useState, useEffect, useCallback } from 'react';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Chip from '@mui/material/Chip';
import MenuItem from '@mui/material/MenuItem';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import Typography from '@mui/material/Typography';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';

import { IconEdit, IconPlus } from '@tabler/icons-react';

import MainCard from 'ui-component/cards/MainCard';
import DataTable from 'ui-component/extended/DataTable';
import { listOrdenesAPI, saveOrdenAPI } from 'api/requests/motosApi';
import { showSuccess, showError, showObligatorios } from 'services/ToastService';

const emptyForm = {
  ordId: null, motId: '', tipoServicio: 'correctivo', prioridad: 'media',
  descripcion: '', horasEstimadas: 0, esoId: 1
};

const PRIORIDAD_COLOR = { baja: 'default', media: 'info', alta: 'warning', urgente: 'error' };

export default function MotosOrdenes() {
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const fetchOrdenes = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await listOrdenesAPI({ rows: rowsPerPage, first: page * rowsPerPage });
      setRows(data.data ?? []);
      setTotal(data.total ?? 0);
    } catch (err) {
      console.error('Error cargando órdenes:', err);
    } finally {
      setLoading(false);
    }
  }, [page, rowsPerPage]);

  useEffect(() => {
    fetchOrdenes();
  }, [fetchOrdenes]);

  const handleNew = () => {
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setForm({
      ordId: row.ordId,
      motId: '', // no se reasigna la moto al editar
      tipoServicio: row.tipoServicio,
      prioridad: row.prioridad,
      descripcion: row.descripcion,
      horasEstimadas: row.horasEstimadas,
      esoId: row.estadoId
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.ordId && !form.motId) {
      showObligatorios(false);
      return;
    }
    setSaving(true);
    try {
      await saveOrdenAPI(form);
      showSuccess('Orden de trabajo guardada correctamente');
      setDialogOpen(false);
      fetchOrdenes();
    } catch (err) {
      console.error('Error guardando orden:', err);
      showError('No fue posible guardar la orden de trabajo');
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    { id: 'numero', label: 'N° Orden', sortable: true },
    { id: 'placa', label: 'Moto', render: (row) => `${row.placa} · ${row.marca}` },
    { id: 'clienteNombre', label: 'Cliente', hideInCard: true },
    {
      id: 'prioridad',
      label: 'Prioridad',
      render: (row) => <Chip size="small" label={row.prioridad} color={PRIORIDAD_COLOR[row.prioridad] || 'default'} />
    },
    {
      id: 'estadoNombre',
      label: 'Estado',
      render: (row) => (
        <Chip size="small" label={row.estadoNombre} sx={{ bgcolor: row.estadoColor, color: '#fff' }} />
      )
    },
    {
      id: 'avance',
      label: '% Avance',
      width: 160,
      // === Math: Math.round((terminadas/totalTareas)*100) resuelto en el backend ===
      render: (row) => (
        <Box sx={{ minWidth: 120 }}>
          <Stack direction="row" justifyContent="space-between">
            <Typography variant="caption">{row.avance}%</Typography>
            {row.tiempoRestanteHoras > 0 && (
              <Typography variant="caption" color="text.secondary">
                {row.tiempoRestanteHoras}h restantes
              </Typography>
            )}
          </Stack>
          <LinearProgress variant="determinate" value={row.avance} sx={{ height: 6, borderRadius: 3 }} />
        </Box>
      )
    }
  ];

  const actions = (row) => [
    { label: 'Editar', icon: <IconEdit size={18} />, color: '#1976d2', command: () => handleEdit(row) }
  ];

  return (
    <MainCard
      title="Órdenes de trabajo"
      secondary={
        <Button variant="contained" startIcon={<IconPlus size={18} />} onClick={handleNew}>
          Nueva orden
        </Button>
      }
    >
      <DataTable
        columns={columns}
        rows={rows}
        total={total}
        loading={loading}
        page={page}
        rowsPerPage={rowsPerPage}
        onPageChange={(e, newPage) => setPage(newPage)}
        onRowsPerPageChange={(e) => {
          setRowsPerPage(parseInt(e.target.value, 10));
          setPage(0);
        }}
        keyExtractor={(row) => row.ordId}
        actions={actions}
        cardTitleRender={(row) => row.numero}
      />

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{form.ordId ? 'Editar orden de trabajo' : 'Nueva orden de trabajo'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            {!form.ordId && (
              <Grid size={{ xs: 12 }}>
                <TextField
                  fullWidth
                  label="ID Motocicleta"
                  value={form.motId}
                  onChange={(e) => setForm({ ...form, motId: e.target.value })}
                  helperText="Usa el ID de la motocicleta registrada en el módulo Motocicletas"
                />
              </Grid>
            )}
            <Grid size={{ xs: 6 }}>
              <TextField
                select
                fullWidth
                label="Tipo de servicio"
                value={form.tipoServicio}
                onChange={(e) => setForm({ ...form, tipoServicio: e.target.value })}
              >
                <MenuItem value="preventivo">Preventivo</MenuItem>
                <MenuItem value="correctivo">Correctivo</MenuItem>
                <MenuItem value="diagnostico">Diagnóstico</MenuItem>
                <MenuItem value="garantia">Garantía</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField
                select
                fullWidth
                label="Prioridad"
                value={form.prioridad}
                onChange={(e) => setForm({ ...form, prioridad: e.target.value })}
              >
                <MenuItem value="baja">Baja</MenuItem>
                <MenuItem value="media">Media</MenuItem>
                <MenuItem value="alta">Alta</MenuItem>
                <MenuItem value="urgente">Urgente</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                multiline
                minRows={2}
                label="Descripción del trabajo"
                value={form.descripcion}
                onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                type="number"
                label="Horas estimadas"
                value={form.horasEstimadas}
                onChange={(e) => setForm({ ...form, horasEstimadas: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancelar</Button>
          <Button variant="contained" disabled={saving} onClick={handleSave}>
            {saving ? 'Guardando…' : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </MainCard>
  );
}
