import { useState, useEffect, useCallback } from 'react';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';

import { IconEdit, IconTrash, IconPlus, IconHistory } from '@tabler/icons-react';

import MainCard from 'ui-component/cards/MainCard';
import DataTable from 'ui-component/extended/DataTable';
import { listClientesAPI, saveClienteAPI, deleteClienteAPI } from 'api/requests/motosApi';
import { showSuccess, showError, showObligatorios } from 'services/ToastService';

const emptyForm = { mclId: null, nombre: '', identificacion: '', telefono: '', email: '', direccion: '', ciudad: 'Pasto', notas: '' };

export default function MotosClientes() {
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const fetchClientes = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await listClientesAPI({ search, rows: rowsPerPage, first: page * rowsPerPage });
      setRows(data.data ?? []);
      setTotal(data.total ?? 0);
    } catch (err) {
      console.error('Error cargando clientes:', err);
    } finally {
      setLoading(false);
    }
  }, [search, page, rowsPerPage]);

  useEffect(() => {
    fetchClientes();
  }, [fetchClientes]);

  const handleNew = () => {
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setForm({ ...emptyForm, ...row });
    setDialogOpen(true);
  };

  const handleDelete = async (mclId) => {
    try {
      await deleteClienteAPI({ mclId });
      showSuccess('Cliente eliminado');
      fetchClientes();
    } catch (err) {
      console.error('Error eliminando cliente:', err);
      showError('No fue posible eliminar el cliente');
    }
  };

  const handleSave = async () => {
    if (!form.nombre || !form.identificacion) {
      showObligatorios(false);
      return;
    }
    setSaving(true);
    try {
      await saveClienteAPI(form);
      showSuccess('Cliente guardado correctamente');
      setDialogOpen(false);
      fetchClientes();
    } catch (err) {
      console.error('Error guardando cliente:', err);
      showError('No fue posible guardar el cliente');
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    { id: 'nombre', label: 'Nombre', sortable: true },
    { id: 'identificacion', label: 'Identificación' },
    { id: 'telefono', label: 'Teléfono' },
    { id: 'email', label: 'Correo', hideInCard: true },
    { id: 'ciudad', label: 'Ciudad', hideInCard: true }
  ];

  const actions = (row) => [
    { label: 'Editar', icon: <IconEdit size={18} />, color: '#1976d2', command: () => handleEdit(row) },
    {
      label: 'Eliminar',
      icon: <IconTrash size={18} />,
      color: '#d32f2f',
      confirm: `¿Eliminar al cliente ${row.nombre}?`,
      command: () => handleDelete(row.mclId)
    }
  ];

  return (
    <MainCard
      title="Clientes del taller"
      secondary={
        <Button variant="contained" startIcon={<IconPlus size={18} />} onClick={handleNew}>
          Nuevo cliente
        </Button>
      }
    >
      <Stack spacing={2}>
        <TextField
          label="Buscar por nombre, identificación o teléfono"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(0);
          }}
          size="small"
        />

        <DataTable
          columns={columns}
          rows={rows}
          total={total}
          loading={loading}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(e, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          keyExtractor={(row) => row.mclId}
          actions={actions}
          cardTitleRender={(row) => row.nombre}
        />
      </Stack>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{form.mclId ? 'Editar cliente' : 'Nuevo cliente'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Nombre completo"
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Identificación"
                value={form.identificacion}
                onChange={(e) => setForm({ ...form, identificacion: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Teléfono"
                value={form.telefono}
                onChange={(e) => setForm({ ...form, telefono: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Correo"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 8 }}>
              <TextField
                fullWidth
                label="Dirección"
                value={form.direccion}
                onChange={(e) => setForm({ ...form, direccion: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="Ciudad"
                value={form.ciudad}
                onChange={(e) => setForm({ ...form, ciudad: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                multiline
                minRows={2}
                label="Notas"
                value={form.notas}
                onChange={(e) => setForm({ ...form, notas: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancelar</Button>
          <Button variant="contained" disabled={saving} onClick={handleSave}>
            {saving ? 'Guardando…' : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </MainCard>
  );
}
