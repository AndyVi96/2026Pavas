import httpCliente from '../services/httpCliente';

// ─── Dashboard ────────────────────────────────────────────────────────────
export const getIndicadoresMotosAPI = () => httpCliente.get('motos/dashboard/indicadores');
export const getDistribucionEstadosAPI = () => httpCliente.get('motos/dashboard/distribucion_estados');

// ─── Clientes ─────────────────────────────────────────────────────────────
export const listClientesAPI = (params) => httpCliente.post('motos/clientes/list_clientes', params);
export const getClienteHistorialAPI = (params) => httpCliente.get('motos/clientes/historial_cliente', params);
export const saveClienteAPI = (params) => httpCliente.post('motos/clientes/save_cliente', params);
export const deleteClienteAPI = (params) => httpCliente.put('motos/clientes/delete_cliente', params);

// ─── Motocicletas ─────────────────────────────────────────────────────────
export const listMotocicletasAPI = (params) => httpCliente.post('motos/motocicletas/list_motocicletas', params);
export const saveMotocicletaAPI = (params) => httpCliente.post('motos/motocicletas/save_motocicleta', params);
export const deleteMotocicletaAPI = (params) => httpCliente.put('motos/motocicletas/delete_motocicleta', params);

// ─── Recepción ────────────────────────────────────────────────────────────
export const saveRecepcionAPI = (params) => httpCliente.post('motos/recepcion/save_recepcion', params);
export const getTiemposRecepcionAPI = (params) => httpCliente.get('motos/recepcion/tiempos_recepcion', params);

// ─── Órdenes de trabajo ───────────────────────────────────────────────────
export const listOrdenesAPI = (params) => httpCliente.post('motos/ordenes/list_ordenes', params);
export const saveOrdenAPI = (params) => httpCliente.post('motos/ordenes/save_orden', params);
export const saveTareaAPI = (params) => httpCliente.post('motos/ordenes/save_tarea', params);
export const toggleTareaAPI = (params) => httpCliente.put('motos/ordenes/toggle_tarea', params);
export const getTareasOrdenAPI = (params) => httpCliente.get('motos/ordenes/tareas_orden', params);
export const getCargaMecanicosAPI = () => httpCliente.get('motos/ordenes/carga_mecanicos');

// ─── Inventario ───────────────────────────────────────────────────────────
export const listInventarioAPI = (params) => httpCliente.post('motos/inventario/list_inventario', params);
export const registrarMovimientoInventarioAPI = (params) => httpCliente.post('motos/inventario/movimiento_inventario', params);
export const saveRepuestoAPI = (params) => httpCliente.post('motos/inventario/save_repuesto', params);

// ─── Facturación ──────────────────────────────────────────────────────────
/**
 * Cálculo en vivo (sin persistir) — usa la MISMA fórmula que el backend,
 * para que la previsualización del formulario nunca se desincronice del total real guardado.
 */
export const calcularFacturaAPI = (params) => httpCliente.post('motos/facturacion/calcular_factura', params);
export const saveFacturaAPI = (params) => httpCliente.post('motos/facturacion/save_factura', params);
export const listFacturasAPI = (params) => httpCliente.post('motos/facturacion/list_facturas', params);
