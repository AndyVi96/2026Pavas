import { lazy } from 'react';
import { Navigate } from 'react-router';

// project imports
import MainLayout from 'layout/MainLayout';
import Loadable from 'ui-component/Loadable';
import PrivateRoute from './PrivateRoute';

// dashboard routing
const DashboardDefault = Loadable(lazy(() => import('views/dashboard/Default')));

// security routing
const ProfilesPage = Loadable(lazy(() => import('views/security/profiles/ProfilePage')));
const UsersPage    = Loadable(lazy(() => import('views/security/users/UsersPage')));

// motos routing — Taller de Motos
const MotosDashboard    = Loadable(lazy(() => import('views/motos/Dashboard')));
const MotosClientes     = Loadable(lazy(() => import('views/motos/Clientes')));
const MotosMotocicletas = Loadable(lazy(() => import('views/motos/Motocicletas')));
const MotosOrdenes      = Loadable(lazy(() => import('views/motos/Ordenes')));
const MotosInventario   = Loadable(lazy(() => import('views/motos/Inventario')));
const MotosFacturacion  = Loadable(lazy(() => import('views/motos/Facturacion')));

// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
  path: '/',
  element: <PrivateRoute />,
  children: [
    {
      element: <MainLayout />,
      children: [
        { path: '/', element: <Navigate to="/home/default" replace /> },
        {
          path: 'home',
          children: [
            { path: 'default', element: <DashboardDefault /> }
          ]
        },
        {
          path: 'security',
          children: [
            { path: 'profiles', element: <ProfilesPage /> },
            { path: 'users',    element: <UsersPage /> }
          ]
        },
        {
          path: 'motos',
          children: [
            { path: 'dashboard',     element: <MotosDashboard /> },
            { path: 'clientes',      element: <MotosClientes /> },
            { path: 'motocicletas',  element: <MotosMotocicletas /> },
            { path: 'ordenes',       element: <MotosOrdenes /> },
            { path: 'inventario',    element: <MotosInventario /> },
            { path: 'facturacion',   element: <MotosFacturacion /> }
          ]
        }
      ]
    }
  ]
};

export default MainRoutes;