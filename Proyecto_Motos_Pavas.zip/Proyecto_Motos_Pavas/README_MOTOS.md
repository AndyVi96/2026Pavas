# 🏍️ Proyecto Motos — Taller de Motocicletas (sobre plantilla Pavas)

Sistema de gestión para talleres de motocicletas, construido **dentro de tu plantilla real Pavas**
(Node.js + Express + MySQL en el backend, React 19 + Material UI + ApexCharts en el frontend).

## ⚠️ Nota importante sobre el prompt original

El documento de especificaciones que subiste (probablemente generado con IA) describe una
arquitectura **Bootstrap + PHP/Laravel + jQuery + DataTables + SweetAlert2 + Chart.js**. Esa NO es
la arquitectura real de tu plantilla `template-pavas.zip`, que en realidad es:

| Capa | Especificación original (genérica) | Pavas (real) |
|---|---|---|
| Backend | PHP / Laravel | **Node.js + Express** |
| Base de datos | MySQL vía Eloquent | **MySQL vía `mysql2` (SQL crudo, pool de conexiones)** |
| Frontend | HTML + Bootstrap + jQuery | **React 19 + Material UI (Berry admin template)** |
| Gráficas | Chart.js | **ApexCharts** (ya integrado en `package.json`) |
| Notificaciones | SweetAlert2 | **react-toastify** (`services/ToastService.js`) |
| Tablas | DataTables (jQuery) | **Componente propio `DataTable.jsx`** (con soporte responsive) |

Por eso este proyecto **no usa Bootstrap ni jQuery**: todo el módulo de Motos se construyó
respetando la arquitectura, convenciones de nombres (`tbl_xxx`, `use_id`, `sta_id`) y patrones
(`routes/controller/service`) que ya existen en tu plantilla. El resultado es 100% compatible con
lo que ya tienes corriendo — el prompt original sirvió como **checklist funcional** (qué módulos
y qué cálculos debía tener el sistema), no como especificación técnica literal.

## ✅ Qué se construyó

### Backend — `server/src/modules/motos/`
Router agregador montado en `/api/motos/*` (ver `motos.routes.js`, registrado en `main.routes.js`):

- **`clientes/`** — CRUD de clientes del taller + historial de motos y órdenes.
- **`motocicletas/`** — CRUD de motos, con cálculo automático del próximo mantenimiento.
- **`recepcion/`** — Registro de ingreso (fotos, accesorios, combustible, firma digital) y cálculo
  de tiempo en taller / días de retraso.
- **`ordenes/`** — Órdenes de trabajo con checklist de tareas, % de avance, tiempo restante y
  carga de trabajo por mecánico.
- **`inventario/`** — Repuestos, movimientos de stock, alertas de stock crítico y días estimados
  antes de agotarse.
- **`facturacion/`** — Motor de cálculo de cotizaciones/facturas (mano de obra, repuestos,
  descuentos, IVA, total redondeado) + endpoint de **solo cálculo** (`/calcular_factura`) para
  previsualización en vivo sin persistir nada.
- **`dashboard/`** — Indicadores agregados: promedios, máximos, mínimos, porcentajes y
  distribución de órdenes por estado.

### Base de datos — `database/motos_schema.sql`
Script completo con todas las tablas nuevas (`tbl_moto_clientes`, `tbl_motocicletas`,
`tbl_moto_recepcion`, `tbl_ordenes_trabajo`, `tbl_orden_tareas`, `tbl_inventario_repuestos`,
`tbl_inventario_movimientos`, `tbl_orden_repuestos`, `tbl_facturas`, catálogo de estados y una
vista analítica). Incluye datos de ejemplo para poder probar el dashboard de inmediato.

**Ejecutar después de tu script base** (`database/bdtemplate.sql` o el que ya uses):
```bash
mysql -u root -p tu_base_de_datos < database/motos_schema.sql
```

### Frontend — `client/src/views/motos/`
- **Dashboard** — indicadores + gráfica de tendencia (ApexCharts) + distribución por estado (donut).
- **Clientes**, **Motocicletas**, **Órdenes de trabajo**, **Inventario** — CRUD completo con
  `DataTable`, diálogos de creación/edición y notificaciones (`react-toastify`).
- **Facturación** — calculadora en tiempo real con `Math` (mano de obra por horas, repuestos,
  descuento, IVA, total redondeado), que usa **la misma fórmula exacta** que el backend para que
  nunca haya descuadre entre lo que ve el usuario y lo que se guarda.
- Menú (`menu-items/motos.js`) y rutas (`routes/MainRoutes.jsx`) ya integrados: al iniciar sesión
  verás "Taller de Motos" en el menú lateral, junto a Seguridad.

## 🧮 Uso de `Math` en el sistema (checklist de la especificación)

| Módulo | Cálculo | Dónde |
|---|---|---|
| Facturación | Mano de obra = horas × valor/hora | `facturacion.service.js` → `calcularFactura` |
| Facturación | Subtotal, descuento, IVA, total redondeado (`Math.round`) | ídem, y espejado en `Facturacion/index.jsx` |
| Órdenes | % de avance (`Math.round`, tope `Math.min(100, …)`) | `ordenes.service.js` → `calcularAvance` |
| Órdenes | Tiempo restante (`Math.max(0, …)`, nunca negativo) | `ordenes.service.js` → `calcularTiempoRestante` |
| Órdenes | Carga de mecánicos (`Math.min`, `Math.round`) | `ordenes.service.js` → `getCargaMecanicos` |
| Motocicletas | Próximo mantenimiento = km actual + 5.000 | `motocicletas.service.js` → `saveMotocicleta` |
| Recepción | Días en taller (`Math.floor`) y días de retraso (`Math.ceil`, `Math.max`) | `recepcion.service.js` → `getTiemposRecepcion` |
| Inventario | Consumo diario promedio y días restantes (`Math.ceil`) | `inventario.service.js` → `listInventario` |
| Inventario | Ganancia y margen sobre repuestos | `facturacion.service.js` → `calcularGananciaRepuestos` |
| Dashboard | Promedios, `Math.max`/`Math.min`, porcentajes | `dashboard.service.js` → `getIndicadores` |
| Consecutivos | `OT-2026-00001`, `COT-2026-0001` (`padStart`) | `ordenes.service.js`, `facturacion.service.js` |

Todos estos cálculos están **integrados en la lógica de negocio real** (no como ejemplos
aislados): se ejecutan cada vez que se lista, guarda o factura algo.

## 🚀 Instalación

```bash
# Backend
cd server
npm install
# configurar variables de entorno (ver server/.env.example si existe, o db.config.js)
npm run dev   # o el script que ya uses (revisa server/package.json)

# Frontend
cd client
npm install
npm run dev
```

Luego ejecuta `database/motos_schema.sql` sobre tu base de datos existente.

## 🗺️ Lo que falta para "producción completa" (honestidad ante todo)

Esto es una base **real y funcional**, no un mockup — pero el pedido original (manuales en PDF,
diagramas de arquitectura, casos de uso, instalador, tests automatizados, roles/permisos
específicos por perfil del taller) es un entregable de varias semanas de trabajo de un equipo.
Lo que sigue, en orden de prioridad, para llegar a ese nivel:

1. **Roles y permisos**: conectar los módulos de Motos al sistema de permisos que ya existe en
   `contexts/permissions/permissionsConfig.js` (igual que hace `security/users`).
2. **Recepción con evidencia visual**: pantalla de ingreso con carga de fotos y firma digital
   (backend ya tiene el endpoint `save_recepcion` listo para recibirlas en base64/JSON).
3. **Reportes PDF/Excel**: el proyecto ya tiene toda la data estructurada; falta la capa de
   exportación (se puede usar `pdfkit`/`exceljs` en el backend).
4. **Selector de cliente/moto por autocompletar** en vez de escribir el ID a mano en los
   formularios de Órdenes y Facturación (ya hay endpoints de listado para alimentar un
   `Autocomplete` de MUI).
5. **Pruebas automatizadas** y **CI/CD** para el despliegue en producción.

Dime cuál de estos quieres que resuelva primero y seguimos.
